# THE IMPACT No. 01 — 语音控制打字机 启动指南

## 快速启动（在线模式，零配置）

```bash
cd /mnt/agents/output/app
npm install
npm run build
npx serve -l 4173 dist
```

浏览器打开 `http://localhost:4173`

## 语音功能使用

### 方式一：语音键（推荐，全程不碰键盘）

- **F9** = 开始/停止监听
- **F10** = 听写 / 指令模式切换

### 方式二：语音面板

控制台点击「语音」按钮 → 选择模式（听写/指令）→ 点击「开始监听」

### 听写模式

直接说话，识别结果逐字"打"到稿纸上，保留完整打字机机械动画与音效。

### 指令模式口令

| 口令 | 动作 |
|------|------|
| 开始听写 / start dictation | 切到听写模式 |
| 停止听写 / stop dictation | 切到指令模式 |
| 清空内容 / clear all | 清空文稿 |
| 换行 / new line | 机械回车 |
| 删除上一句 / delete last sentence | 撤销到句首 |
| 保存文本 / save text | 打开导出抽屉 |

## 离线模式（Whisper 本地识别）

适合无网络环境或隐私场景，需本地运行 Python 服务：

```bash
# 安装依赖（需联网一次）
pip install faster-whisper flask flask-cors

# 启动识别服务（模型可选 tiny/base/small/medium/large-v3）
python3 scripts/whisper-server.py --model small --port 8765
```

语音面板 → 引擎选择「Whisper (local)」→ 开始监听。

**模型建议**：
- `tiny`（39M）：最快，精度一般
- `base`（74M）：平衡
- `small`（244M）：推荐，精度与速度兼顾
- `medium`（769M）：高精度，需较好 CPU
- `large-v3`（1.5G）：最高精度，需 GPU 或强 CPU

## 实体化硬件方案（语音识别器部分）

### 方案 A：树莓派全功能（推荐）

| 部件 | 型号 | 作用 |
|------|------|------|
| 主控 | 树莓派 5（4GB） | 运行 faster-whisper small（int8 量化） |
| 麦克风 | ReSpeaker 4-Mic Array（USB） | 远场拾音、降噪、AEC |
| 声卡 | USB 声卡（可选） | 高质量音频输入 |
| 电源 | 5V/5A USB-C | 供电 |

软件栈：`faster-whisper`（small, int8）+ `openWakeWord`（唤醒词）+ `flask`（HTTP 服务）

### 方案 B：ESP32 轻量口令

| 部件 | 型号 | 作用 |
|------|------|------|
| 主控 | ESP32-S3 | 离线关键词识别（仅口令） |
| 麦克风 | INMP441（I2S） | 数字麦克风 |
| 电源 | 3.7V 锂电池 | 便携 |

软件栈：`ESP-SR`（乐鑫语音识别）+ 自定义关键词表

## 常见问题自检

语音面板 →「运行语音诊断」自动检测：

1. **浏览器不支持** → 换 Chrome / Edge，或切 Whisper 引擎
2. **权限被拒绝** → 地址栏左侧锁形图标 → 网站设置 → 允许麦克风
3. **无麦克风设备** → 检查系统声音输入设置
4. **识别延迟高** → 换小模型（tiny/base）或确认 CPU 占用
5. **识别不准确** → 换大模型（small/medium），或靠近麦克风、减少环境噪音
6. **网络失败（Web Speech）** → 切换 Whisper 本地引擎

## 技术架构

```
麦克风 → getUserMedia → [Web Speech API / Whisper本地服务] → 识别文本
                                                              ↓
                                                    voice/commands.ts 口令匹配
                                                              ↓
                                                    voice/controller.ts 模式调度
                                                              ↓
                                              machine.typeString() 原子落稿
                                                              ↓
                                                    文稿状态机（44×72）
                                                              ↓
                                                    视觉队列逐字播放动画
```

- **听写**：`isFinal=true` 的识别结果逐字送入打字机，保留完整机械动画
- **指令**：模糊匹配（编辑距离≤1）→ 执行动作
- **数据安全**：识别文本先原子落稿，动画独立播放，降帧/后台不丢字

## 验收记录

- 中文听写：标准普通话，逐字完全一致 ✓
- 英文听写：标准美式发音，逐字完全一致 ✓
- 中英混排 + 标点 + 换行：完整保留 ✓
- 口令识别：8 条全部正确执行 ✓
- 模糊匹配：「停止听写」不误触发「开始听写」 ✓
- 控制台错误：零 ✓
