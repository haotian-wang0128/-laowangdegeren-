#!/usr/bin/env python3
"""
THE IMPACT No. 01 — Whisper 本地语音识别服务
浏览器端 POST /transcribe → faster-whisper → 返回文本

依赖安装：
  pip install faster-whisper flask flask-cors

启动：
  python3 scripts/whisper-server.py --model small --port 8765

实体化（树莓派 5）：
  pip install faster-whisper flask flask-cors
  python3 scripts/whisper-server.py --model small --device cpu --compute int8
"""
import argparse
import io
import tempfile
import os

parser = argparse.ArgumentParser()
parser.add_argument('--model', default='small', help='tiny / base / small / medium / large-v3')
parser.add_argument('--port', type=int, default=8765)
parser.add_argument('--device', default='cpu')
parser.add_argument('--compute', default='int8', help='int8 / float16 / float32')
args = parser.parse_args()

print(f'[whisper-server] 加载模型 {args.model} (device={args.device}, compute={args.compute})…', flush=True)

from faster_whisper import WhisperModel
from flask import Flask, request, jsonify
from flask_cors import CORS

model = WhisperModel(args.model, device=args.device, compute_type=args.compute)
app = Flask(__name__)
CORS(app)  # 允许浏览器跨域（localhost:5173 → 127.0.0.1:8765）

print(f'[whisper-server] 模型就绪，监听 http://127.0.0.1:{args.port}', flush=True)


@app.route('/health', methods=['GET'])
def health():
    return jsonify({'ok': True, 'model': args.model, 'device': args.device})


@app.route('/transcribe', methods=['POST'])
def transcribe():
    if 'file' not in request.files:
        return jsonify({'error': 'missing file'}), 400
    f = request.files['file']
    lang = request.form.get('lang', 'zh')
    # 保存到临时文件（faster-whisper 需要文件路径或 file-like，webm/opus 需要 ffmpeg 解码）
    with tempfile.NamedTemporaryFile(delete=False, suffix='.webm') as tmp:
        tmp.write(f.read())
        tmp_path = tmp.name
    try:
        segments, _info = model.transcribe(
            tmp_path,
            language=lang,
            beam_size=5,
            vad_filter=True,
            vad_parameters={'min_silence_duration_ms': 500},
        )
        text = ''.join(s.text for s in segments).strip()
        return jsonify({'text': text})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        os.unlink(tmp_path)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=args.port, threaded=True)
