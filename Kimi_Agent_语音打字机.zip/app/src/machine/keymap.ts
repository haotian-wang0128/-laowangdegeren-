// 四行键位布局与字符→键位/字杆映射（未知字符经虚构字杆落纸）
export interface KeyDef {
  id: string // e.g. k-r1-c4
  char: string
  row: number // 0..3
  col: number // 0..10
  x: number
  y: number
  z: number
}

export const KEY_ROWS: string[] = ['1234567890-', 'qwertyuiop[', 'asdfghjkl;\'', 'zxcvbnm,./']

const ROW_Y = [0.104, 0.094, 0.084, 0.074]
const ROW_Z = [0.018, 0.052, 0.086, 0.12]
const ROW_STAGGER = [0, 0.007, 0.012, 0.02]
const KEY_SPACING = 0.0265

export const KEYS: KeyDef[] = []
KEY_ROWS.forEach((rowChars, row) => {
  const n = rowChars.length
  const x0 = -((n - 1) / 2) * KEY_SPACING + ROW_STAGGER[row] - 0.008
  for (let col = 0; col < n; col++) {
    KEYS.push({
      id: `k-r${row}-c${col}`,
      char: rowChars[col],
      row,
      col,
      x: x0 + col * KEY_SPACING,
      y: ROW_Y[row],
      z: ROW_Z[row],
    })
  }
})

const charToKey = new Map<string, string>()
for (const k of KEYS) charToKey.set(k.char, k.id)

export function keyIdForChar(char: string): string {
  const c = char.toLowerCase()
  const direct = charToKey.get(c)
  if (direct) return direct
  if (c === ' ') return 'space'
  // 虚构字杆：Unicode 字符按码点哈希映射到键盘中段
  let h = 0
  for (let i = 0; i < char.length; i++) h = (h * 31 + char.charCodeAt(i)) >>> 0
  const mid = KEYS.filter((k) => k.row === 1 || k.row === 2)
  return mid[h % mid.length].id
}

export const SPACEBAR_ID = 'space'
