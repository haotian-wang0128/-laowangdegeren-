// 击键时序序列器
// 数据层与动画层彻底分离：所有输入（单键/IME 整段）先原子提交到文稿状态机，
// 再进入独立的视觉作业队列播放 240ms/720ms 机械动画。
// 浏览器降帧、后台节流、动画暂停都不会丢字；视觉队列溢出时只跳帧不改数据。
import { bus } from '@/app/bus'
import { doc } from '@/document/model'
import { keyIdForChar } from './keymap'
import { useAppStore } from '@/app/store'

export const CHAR_DURATION = 240
export const RETURN_DURATION = 720
export const TRACE_DURATION = 2600

export interface MotionState {
  activeKey: string | null
  keyT: number // 键帽下沉 0..1
  linkT: number // 连杆行程 0..1
  typebarT: number // 字杆上扬 0..1
  ribbonT: number // 色带提升 0..1
  escapeT: number // 棘爪冲击 0..1
  impactT: number // 撞击闪光 0..1
  bellT: number // 铃震 0..1
  tracePart: string | null // 慢速追踪当前高亮的传动链环节
  busy: boolean
}

type JobType = 'char' | 'backspace' | 'return' | 'trace'

interface Job {
  type: JobType
  char: string
  keyId: string
  toLine: number // 本作业完成后视觉光标应处的位置（绝对值，丢帧不漂移）
  toCol: number
  bell: boolean // 撞击后是否鸣铃
  t0: number
  duration: number
  fired: Set<number> // 已触发的时刻标记(ms)
}

// 正弦式起落包络：从 0 升到 1 再回到 0
function pulse(t: number, start: number, peak: number, end: number): number {
  if (t <= start || t >= end) return 0
  if (t <= peak) return ease((t - start) / (peak - start))
  return 1 - ease((t - peak) / (end - peak))
}
function ease(x: number): number {
  return x * x * (3 - 2 * x)
}

const TRACE_WINDOWS: Array<[number, number, string]> = [
  [0.0, 0.15, 'keycap'],
  [0.15, 0.29, 'keylever'],
  [0.29, 0.43, 'link'],
  [0.43, 0.61, 'typebar'],
  [0.61, 0.73, 'vibrator'],
  [0.73, 0.87, 'escapement'],
  [0.87, 1.0, 'carriage'],
]

class Machine {
  motion: MotionState = {
    activeKey: null,
    keyT: 0,
    linkT: 0,
    typebarT: 0,
    ribbonT: 0,
    escapeT: 0,
    impactT: 0,
    bellT: 0,
    tracePart: null,
    busy: false,
  }

  // 视觉光标：随动画逐字推进；空闲时与文稿光标一致
  view = { line: 0, col: 0 }

  private queue: Job[] = []
  private active: Job | null = null
  private bellStart = -1
  private lastEnd = -1 // 上一作业的墙钟完成时刻：低帧率时让后续作业承接该时刻追帧

  constructor() {
    this.view = { line: doc.cursor.line, col: doc.cursor.col }
  }

  private get timeScale(): number {
    let s = useAppStore.getState().reducedMotion ? 2.2 : 1
    // 队列积压时机构提速追赶
    if (this.queue.length > 2) s *= 1.8
    if (this.queue.length > 6) s *= 1.5
    return s
  }

  isBusy(): boolean {
    return !!this.active || this.queue.length > 0
  }

  // ---- 单键输入：数据立即落稿，动画入队 ----
  typeChar(char: string): void {
    if (useAppStore.getState().explode > 8) {
      bus.emit('ui:notice', { key: 'noticeExplode' })
      bus.emit('machine:reject', { reason: 'exploded' })
      return
    }
    const res = doc.commitChar(char)
    if (!res.ok) {
      bus.emit('machine:reject', { reason: res.reason ?? 'lineFull' })
      bus.emit('ui:notice', { key: res.reason === 'pageFull' ? 'noticePageFull' : 'noticeLineFull' })
      // 满行 + 自动回车：归位后重打该字符
      if (res.reason === 'lineFull' && useAppStore.getState().autoReturn && !doc.isPageFull()) {
        this.carriageReturn()
        this.typeChar(char)
      }
      return
    }
    this.enqueueChar(char, res.bell, doc.cursor.line, doc.cursor.col)
  }

  // ---- IME 整段提交：一次原子落稿（一次撤销步），动画逐字入队，绝不截断 ----
  typeString(text: string): void {
    if (!text) return
    if (useAppStore.getState().explode > 8) {
      bus.emit('ui:notice', { key: 'noticeExplode' })
      bus.emit('machine:reject', { reason: 'exploded' })
      return
    }
    const { jobs, rejected } = doc.commitString(text, useAppStore.getState().autoReturn)
    for (const j of jobs) {
      if (j.char === '\n') {
        this.enqueue({
          type: 'return',
          char: '',
          keyId: '',
          toLine: j.toLine,
          toCol: 0,
          bell: false,
          t0: 0,
          duration: RETURN_DURATION,
          fired: new Set(),
        })
      } else {
        this.enqueueChar(j.char, j.bell, j.toLine, j.toCol)
      }
    }
    if (jobs.some((j) => j.char === '\n')) bus.emit('machine:carriageReturn', {})
    if (rejected) {
      // 右界/页满：显式提示未接受的字符，绝不静默
      bus.emit('machine:reject', { reason: doc.isPageFull() ? 'pageFull' : 'lineFull' })
      bus.emit('ui:notice', { key: 'noticeRejected', detail: rejected })
    }
  }

  backspace(): void {
    if (useAppStore.getState().explode > 8) {
      bus.emit('ui:notice', { key: 'noticeExplode' })
      return
    }
    if (!doc.backspace()) return
    this.enqueue({
      type: 'backspace',
      char: '',
      keyId: '',
      toLine: doc.cursor.line,
      toCol: doc.cursor.col,
      bell: false,
      t0: 0,
      duration: CHAR_DURATION,
      fired: new Set(),
    })
  }

  carriageReturn(): void {
    if (useAppStore.getState().explode > 8) {
      bus.emit('ui:notice', { key: 'noticeExplode' })
      return
    }
    if (!doc.carriageReturn()) return
    this.enqueue({
      type: 'return',
      char: '',
      keyId: '',
      toLine: doc.cursor.line,
      toCol: 0,
      bell: false,
      t0: 0,
      duration: RETURN_DURATION,
      fired: new Set(),
    })
    bus.emit('machine:carriageReturn', {})
  }

  startTrace(char: string): void {
    this.queue = this.queue.filter((j) => j.type !== 'trace')
    this.enqueue({
      type: 'trace',
      char,
      keyId: keyIdForChar(char || 'a'),
      toLine: this.view.line,
      toCol: this.view.col,
      bell: false,
      t0: 0,
      duration: TRACE_DURATION,
      fired: new Set(),
    })
  }

  ringBell(): void {
    this.bellStart = performance.now()
  }

  // 撤销/重做/清空/换新纸后：丢弃残余动画（数据已原子提交），视觉光标对齐数据光标
  flushVisuals(): void {
    this.queue = []
    this.active = null
    this.lastEnd = -1
    this.view = { line: doc.cursor.line, col: doc.cursor.col }
  }

  private enqueueChar(char: string, bell: boolean, toLine: number, toCol: number): void {
    this.enqueue({ type: 'char', char, keyId: keyIdForChar(char), toLine, toCol, bell, t0: 0, duration: CHAR_DURATION, fired: new Set() })
  }

  private enqueue(job: Job): void {
    // 视觉队列仅影响动画；溢出丢弃最旧作业只跳帧，数据不受影响（toCol 为绝对坐标，不漂移）
    if (this.queue.length >= 512) this.queue.shift()
    this.queue.push(job)
    // 入队即置忙并同步 UI（不等下一帧），Undo/Redo 立即转为禁用
    this.motion.busy = true
    const s = useAppStore.getState()
    if (!s.machineBusy) s.setMachineBusy(true)
  }

  // ---- 每帧推进（由场景 useFrame 调用）----
  // 低帧率/后台节流时按墙钟时间同帧连播多个已完成作业，队列永不因帧率积压
  update(now: number): void {
    const m = this.motion
    m.keyT = 0
    m.linkT = 0
    m.typebarT = 0
    m.ribbonT = 0
    m.escapeT = 0
    m.impactT = Math.max(0, m.impactT - 0.08)
    m.tracePart = null
    m.activeKey = null

    // 铃震衰减
    if (this.bellStart >= 0) {
      const bt = (now - this.bellStart) / 900
      m.bellT = bt >= 1 ? 0 : (1 - bt) * Math.abs(Math.sin(bt * 28))
      if (bt >= 1) this.bellStart = -1
    }

    let guard = 0
    while (guard++ < 64) {
      if (!this.active) {
        if (this.queue.length === 0) {
          this.lastEnd = -1
          break
        }
        this.active = this.queue.shift()!
        // 承接上一作业的完成时刻：降帧/后台恢复时积压作业按墙钟连播，不会因帧率滞留
        this.active.t0 = this.lastEnd > 0 && this.lastEnd <= now ? this.lastEnd : now
      }
      const job = this.active
      const d = job.duration / this.timeScale
      const t = Math.min(1, (now - job.t0) / d)
      m.activeKey = job.keyId || null

      const fire = (mark: number, fn: () => void) => {
        if (t * job.duration >= mark && !job.fired.has(mark)) {
          job.fired.add(mark)
          fn()
        }
      }

      if (job.type === 'trace') {
        const win = TRACE_WINDOWS.find(([a, b]) => t >= a && t < b)
        m.tracePart = win ? win[2] : null
        m.keyT = pulse(t, 0.0, 0.08, 0.2)
        m.linkT = pulse(t, 0.15, 0.24, 0.4)
        m.typebarT = pulse(t, 0.3, 0.52, 0.78)
        m.ribbonT = pulse(t, 0.4, 0.55, 0.75)
        m.escapeT = pulse(t, 0.72, 0.79, 0.9)
        for (const [a, , part] of TRACE_WINDOWS) {
          fire(a * job.duration, () => bus.emit('machine:traceTick', { part }))
        }
        if (t >= 1) {
          this.lastEnd = job.t0 + d
          this.active = null
          continue
        }
        break
      }

      if (job.type === 'return') {
        fire(0, () => {
          this.view = { line: job.toLine, col: job.toCol } // 滑架经插值平滑归位
        })
        m.escapeT = t < 0.85 ? 0.35 + 0.2 * Math.sin(t * 40) : pulse(t, 0.85, 0.92, 1)
        if (t >= 1) {
          this.lastEnd = job.t0 + d
          this.active = null
          continue
        }
        break
      }

      if (job.type === 'backspace') {
        m.escapeT = pulse(t, 0.3, 0.5, 0.75)
        fire(0, () => bus.emit('machine:key', { char: '' }))
        fire(120, () => {
          bus.emit('machine:escape', {})
          this.view = { line: job.toLine, col: job.toCol }
        })
        if (t >= 1) {
          this.lastEnd = job.t0 + d
          this.active = null
          continue
        }
        break
      }

      // 普通击键时序（时刻单位 ms，按 240ms 全程标注）
      m.keyT = pulse(t, 0, 0.17, 0.75) // 0–40ms 键帽下沉
      m.linkT = pulse(t, 0.08, 0.3, 0.8) // 连杆
      m.typebarT = pulse(t, 0.22, 0.52, 0.92) // 字杆上扬→归位
      m.ribbonT = pulse(t, 0.3, 0.47, 0.72) // 色带抬起
      m.escapeT = pulse(t, 0.5, 0.64, 0.85) // 逃逸释放

      fire(0, () => bus.emit('machine:key', { char: job.char }))
      fire(25, () => bus.emit('machine:link', {}))
      fire(100, () => {
        // 撞击点：纯视觉/听觉效果 + 视觉光标进一格（数据早已原子落稿）
        m.impactT = 1
        bus.emit('machine:impact', { char: job.char })
        this.view = { line: job.toLine, col: job.toCol }
        if (job.bell) bus.emit('doc:bell', { line: job.toLine })
      })
      fire(120, () => bus.emit('machine:escape', {}))
      fire(190, () => bus.emit('machine:barReturn', {}))

      if (t >= 1) {
        this.lastEnd = job.t0 + d
        this.active = null
        continue // 同帧推进下一个作业，消除低帧率积压
      }
      break
    }

    m.busy = !!this.active || this.queue.length > 0
  }
}

export const machine = new Machine()
