// 统一事件总线 —— app/scene/machine/document/audio/ui 各层通过它解耦通信
export type BusEvents = {
  'machine:key': { char: string } // 键帽下沉（t=0）
  'machine:link': Record<string, never> // 连杆牵动（t≈25ms）
  'machine:impact': { char: string } // 字杆撞击落字（t=100ms）
  'machine:escape': Record<string, never> // 逃逸释放（t≈120ms）
  'machine:barReturn': Record<string, never> // 字杆归位（t≈190ms）
  'machine:reject': { reason: 'lineFull' | 'exploded' | 'pageFull' }
  'machine:carriageReturn': Record<string, never>
  'machine:traceTick': { part: string } // 慢速追踪每一段的轻响
  'doc:bell': { line: number }
  'doc:pageFull': Record<string, never>
  'doc:changed': Record<string, never>
  'doc:newSheet': { page: number }
  'ui:trace': { char: string }
  'ui:notice': { key: string; detail?: string }
  'voice:changed': Record<string, never>
  'audio:unlock': Record<string, never>
}

type Handler<T> = (payload: T) => void

class Bus {
  private map = new Map<keyof BusEvents, Set<Handler<never>>>()

  on<K extends keyof BusEvents>(ev: K, fn: Handler<BusEvents[K]>): () => void {
    let set = this.map.get(ev)
    if (!set) {
      set = new Set()
      this.map.set(ev, set)
    }
    set.add(fn as Handler<never>)
    return () => set!.delete(fn as Handler<never>)
  }

  emit<K extends keyof BusEvents>(ev: K, payload: BusEvents[K]): void {
    this.map.get(ev)?.forEach((fn) => (fn as Handler<BusEvents[K]>)(payload))
  }
}

export const bus = new Bus()
