import { create } from 'zustand'
import type { Lang } from './i18n'

export type CameraMode = 'write' | 'mechanism' | 'inspect'
export type OverstrikePolicy = 'mark' | 'top'

interface AppState {
  lang: Lang
  sound: boolean
  cameraMode: CameraMode
  explode: number // 0–100
  cutaway: boolean
  autoReturn: boolean
  imeMode: boolean
  voicePanelOpen: boolean
  exportOpen: boolean
  overstrikePolicy: OverstrikePolicy
  noticeKey: string | null // i18n key，顶部提示
  noticeDetail: string // 提示附加内容（如被拒字符）
  machineBusy: boolean // 机械动画队列忙碌（Undo/Redo 据此禁用）
  selectedPart: string | null
  traceUntil: number // 慢速追踪截止时间戳(ms)，0 = 无
  traceChar: string
  reducedMotion: boolean
  docVersion: number // 文稿变更计数，驱动 UI 刷新
  setLang: (l: Lang) => void
  toggleSound: () => void
  setCameraMode: (m: CameraMode) => void
  setExplode: (v: number) => void
  toggleCutaway: () => void
  toggleAutoReturn: () => void
  toggleIme: () => void
  setVoicePanelOpen: (v: boolean) => void
  setExportOpen: (v: boolean) => void
  setOverstrikePolicy: (p: OverstrikePolicy) => void
  setNotice: (k: string | null, detail?: string) => void
  setMachineBusy: (b: boolean) => void
  setSelectedPart: (p: string | null) => void
  startTrace: (char: string) => void
  bumpDoc: () => void
}

const LANG_KEY = 'impact-lang'

function detectReducedMotion(): boolean {
  if (typeof window === 'undefined' || !window.matchMedia) return false
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

export const useAppStore = create<AppState>((set) => ({
  lang: (typeof localStorage !== 'undefined' && (localStorage.getItem(LANG_KEY) as Lang)) || 'zh',
  sound: true,
  cameraMode: 'write',
  explode: 0,
  cutaway: false,
  autoReturn: false,
  imeMode: false,
  voicePanelOpen: false,
  exportOpen: false,
  overstrikePolicy: 'mark',
  noticeKey: null,
  noticeDetail: '',
  machineBusy: false,
  selectedPart: null,
  traceUntil: 0,
  traceChar: ' ',
  reducedMotion: detectReducedMotion(),
  docVersion: 0,
  setLang: (l) => {
    localStorage.setItem(LANG_KEY, l)
    document.documentElement.lang = l === 'zh' ? 'zh-CN' : 'en'
    set({ lang: l })
  },
  toggleSound: () => set((s) => ({ sound: !s.sound })),
  setCameraMode: (m) => set({ cameraMode: m, selectedPart: null }),
  setExplode: (v) =>
    set((s) => ({
      explode: v,
      noticeKey: v > 8 ? 'noticeExplode' : s.noticeKey === 'noticeExplode' ? null : s.noticeKey,
    })),
  toggleCutaway: () => set((s) => ({ cutaway: !s.cutaway })),
  toggleAutoReturn: () => set((s) => ({ autoReturn: !s.autoReturn })),
  toggleIme: () => set((s) => ({ imeMode: !s.imeMode })),
  setVoicePanelOpen: (v) => set({ voicePanelOpen: v }),
  setExportOpen: (v) => set({ exportOpen: v }),
  setOverstrikePolicy: (p) => set({ overstrikePolicy: p }),
  setNotice: (k, detail = '') => set({ noticeKey: k, noticeDetail: detail }),
  setMachineBusy: (b) => set({ machineBusy: b }),
  setSelectedPart: (p) => set({ selectedPart: p }),
  startTrace: (char) => set({ traceUntil: performance.now() + 2600, traceChar: char }),
  bumpDoc: () => set((s) => ({ docVersion: s.docVersion + 1 })),
}))
