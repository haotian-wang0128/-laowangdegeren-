// Unicode 输入法适配器：隐藏 textarea 捕获 IME 合成
// composition commit 原子落稿（一次撤销步），机械动画经独立视觉队列逐字播放；
// 合成期间用 ref 同步判定，与紧随的 input 事件去重，不丢字不重复。
import { useEffect, useRef, useState } from 'react'
import { useAppStore } from '@/app/store'
import { t } from '@/app/i18n'
import { machine } from '@/machine/sequencer'
import { scheduleImeFocus } from './focus'

export function ImeAdapter() {
  const enabled = useAppStore((s) => s.imeMode)
  const lang = useAppStore((s) => s.lang)
  const ref = useRef<HTMLTextAreaElement>(null)
  const [preview, setPreview] = useState('')
  const composingRef = useRef(false)
  const committedLen = useRef(0)
  const lastCommitRef = useRef<{ text: string; at: number } | null>(null)

  useEffect(() => {
    if (enabled) {
      committedLen.current = 0
      lastCommitRef.current = null
      const id = window.setTimeout(() => ref.current?.focus({ preventScroll: true }), 60)
      return () => window.clearTimeout(id)
    }
    setPreview('')
  }, [enabled])

  // 浮层（导出抽屉 / 零件卡）关闭或机械队列清空后自动恢复 IME 焦点——下一帧执行，不抢表单焦点
  useEffect(() => {
    let prevOpen = useAppStore.getState().exportOpen
    let prevPart = useAppStore.getState().selectedPart
    let prevBusy = useAppStore.getState().machineBusy
    const unsub = useAppStore.subscribe((s) => {
      if ((prevOpen && !s.exportOpen) || (prevPart && !s.selectedPart) || (prevBusy && !s.machineBusy)) scheduleImeFocus()
      prevOpen = s.exportOpen
      prevPart = s.selectedPart
      prevBusy = s.machineBusy
    })
    return unsub
  }, [])

  if (!enabled) return null

  return (
    <>
      {preview && (
        <div className="ime-preview" aria-live="polite">
          <span className="ime-label">{t(lang, 'composing')}</span>
          <span className="ime-text">{preview}</span>
        </div>
      )}
      <textarea
        id="ime-hidden"
        ref={ref}
        className="ime-textarea"
        aria-label={lang === 'zh' ? '输入法适配输入区' : 'IME adapter input'}
        autoCapitalize="off"
        autoCorrect="off"
        autoComplete="off"
        spellCheck={false}
        onCompositionStart={() => {
          composingRef.current = true
        }}
        onCompositionUpdate={(e) => setPreview(e.data)}
        onCompositionEnd={(e) => {
          composingRef.current = false
          setPreview('')
          const text = e.data
          if (text) {
            machine.typeString(text) // 原子提交，任意长度不截断
            lastCommitRef.current = { text, at: performance.now() }
          }
          committedLen.current = 0
          // 下一帧清空，避免与紧随其后的 input 事件竞争
          requestAnimationFrame(() => {
            if (ref.current) {
              ref.current.value = ''
              committedLen.current = 0
            }
          })
        }}
        onInput={(e) => {
          const ne = e.nativeEvent as InputEvent
          const el = e.currentTarget
          if (composingRef.current || ne.isComposing) return
          if (ne.inputType === 'insertCompositionText') return // 已由 compositionend 处理
          const text = ne.data ?? el.value.slice(committedLen.current)
          // 某些浏览器在 compositionend 后再发一次相同内容的 input：去重
          const lc = lastCommitRef.current
          if (lc && text === lc.text && performance.now() - lc.at < 300) {
            committedLen.current = el.value.length
            return
          }
          if (text) machine.typeString(text) // 非合成输入同样走原子通道
          committedLen.current = el.value.length
        }}
        onKeyDown={(e) => {
          if (composingRef.current) return
          if (e.key === 'Enter') {
            e.preventDefault()
            machine.carriageReturn()
          } else if (e.key === 'Backspace' && e.currentTarget.value === '') {
            machine.backspace()
          }
        }}
        onBlur={() => {
          // 浮层打开期间不抢焦点；其余情况下 IME 模式保持输入焦点
          // （忙碌不再阻断——数据层原子提交，输入始终有效）
          window.setTimeout(() => {
            const s = useAppStore.getState()
            if (s.imeMode && !s.exportOpen && !s.selectedPart) ref.current?.focus({ preventScroll: true })
          }, 80)
        }}
      />
    </>
  )
}
