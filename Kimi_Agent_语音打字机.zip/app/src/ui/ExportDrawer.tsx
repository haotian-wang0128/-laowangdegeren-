// 导出抽屉：DOCX 生成与叠印保留策略
import { useState } from 'react'
import { useAppStore } from '@/app/store'
import { t } from '@/app/i18n'
import { exportDocx } from '@/export/docxExport'
import { audio } from '@/audio/synth'
import { scheduleImeFocus } from './focus'

export function ExportDrawer() {
  const open = useAppStore((s) => s.exportOpen)
  const setOpen = useAppStore((s) => s.setExportOpen)
  const lang = useAppStore((s) => s.lang)
  const policy = useAppStore((s) => s.overstrikePolicy)
  const setPolicy = useAppStore((s) => s.setOverstrikePolicy)
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState(false)

  if (!open) return null

  const run = async () => {
    setBusy(true)
    setDone(false)
    try {
      await exportDocx(policy)
      setDone(true)
    } finally {
      setBusy(false)
    }
  }

  const close = () => {
    setOpen(false)
    scheduleImeFocus() // 抽屉关闭后下一帧归还 IME 焦点
  }

  return (
    <div className="drawer-wrap" role="dialog" aria-label={t(lang, 'exportTitle')}>
      <button type="button" className="drawer-scrim" onClick={close} aria-label={t(lang, 'close')} />
      <div className="drawer">
        <div className="drawer-head">
          <span>{t(lang, 'exportTitle')}</span>
          <button type="button" className="part-close" onClick={close} aria-label={t(lang, 'close')}>
            ×
          </button>
        </div>
        <div className="drawer-body">
          <div className="ctl-label">{t(lang, 'exportOverstrike')}</div>
          <label className="radio-row">
            <input
              type="radio"
              name="overstrike"
              checked={policy === 'mark'}
              onChange={() => setPolicy('mark')}
            />
            <span>{t(lang, 'overstrikeMark')}</span>
          </label>
          <label className="radio-row">
            <input
              type="radio"
              name="overstrike"
              checked={policy === 'top'}
              onChange={() => setPolicy('top')}
            />
            <span>{t(lang, 'overstrikeTop')}</span>
          </label>
          <button
            type="button"
            className="ctl-btn export-run"
            disabled={busy}
            onClick={() => {
              audio.drawer()
              void run()
            }}
          >
            {busy ? '…' : t(lang, 'exportRun')}
          </button>
          {done && <div className="export-done">{t(lang, 'exportDone')}</div>}
        </div>
      </div>
    </div>
  )
}
