// 语音控制面板：模式开关、引擎选择、口令列表、诊断、实体化物料清单
import { useEffect, useState } from 'react'
import { useAppStore } from '@/app/store'
import { t } from '@/app/i18n'
import { voice } from '@/voice/controller'
import { runVoiceDiagnostics } from '@/voice/diagnostics'
import type { DiagItem } from '@/voice/diagnostics'
import { COMMANDS } from '@/voice/commands'
import { audio } from '@/audio/synth'
import { scheduleImeFocus } from './focus'

export function VoicePanel() {
  const lang = useAppStore((s) => s.lang)
  const open = useAppStore((s) => s.voicePanelOpen)
  const setOpen = useAppStore((s) => s.setVoicePanelOpen)
  const [, force] = useState(0)
  const [diag, setDiag] = useState<DiagItem[] | null>(null)
  const [diagBusy, setDiagBusy] = useState(false)

  useEffect(() => {
    const off = voice && (() => {})
    void off
    const t = window.setInterval(() => force((x) => x + 1), 400) // 轮询刷新状态（简单可靠）
    return () => window.clearInterval(t)
  }, [])

  if (!open) return null
  const st = voice.state

  const close = () => {
    setOpen(false)
    scheduleImeFocus()
  }

  const runDiag = async () => {
    setDiagBusy(true)
    setDiag(await runVoiceDiagnostics())
    setDiagBusy(false)
  }

  return (
    <div className="drawer-wrap" role="dialog" aria-label={t(lang, 'voicePanelTitle')}>
      <button type="button" className="drawer-scrim" onClick={close} aria-label={t(lang, 'close')} />
      <div className="drawer voice-drawer">
        <div className="drawer-head">
          <span>{t(lang, 'voicePanelTitle')}</span>
          <button type="button" className="part-close" onClick={close} aria-label={t(lang, 'close')}>
            ×
          </button>
        </div>
        <div className="drawer-body voice-body">
          {/* 模式与引擎 */}
          <div className="voice-section">
            <div className="ctl-label">{t(lang, 'voiceMode')}</div>
            <div className="ctl-group">
              <button
                type="button"
                className={`ctl-btn${st.mode === 'off' ? ' active' : ''}`}
                onClick={() => {
                  voice.setMode('off')
                  audio.uiTick()
                }}
              >
                {t(lang, 'voiceOff')}
              </button>
              <button
                type="button"
                className={`ctl-btn${st.mode === 'dictation' ? ' active' : ''}`}
                onClick={() => {
                  voice.setMode('dictation')
                  audio.uiTick()
                }}
              >
                {t(lang, 'voiceDictation')}
              </button>
              <button
                type="button"
                className={`ctl-btn${st.mode === 'command' ? ' active' : ''}`}
                onClick={() => {
                  voice.setMode('command')
                  audio.uiTick()
                }}
              >
                {t(lang, 'voiceCommand')}
              </button>
            </div>
          </div>

          <div className="voice-section">
            <div className="ctl-label">{t(lang, 'voiceEngine')}</div>
            <div className="ctl-group">
              <button
                type="button"
                className={`ctl-btn${st.engine === 'webspeech' ? ' active' : ''}`}
                onClick={() => voice.setEngine('webspeech')}
              >
                Web Speech
              </button>
              <button
                type="button"
                className={`ctl-btn${st.engine === 'whisper' ? ' active' : ''}`}
                onClick={() => voice.setEngine('whisper')}
              >
                Whisper (local)
              </button>
            </div>
          </div>

          {/* 启停 */}
          <div className="voice-section">
            <button
              type="button"
              className={`ctl-btn voice-toggle${st.listening ? ' active' : ''}`}
              onClick={() => {
                if (st.listening) voice.stopListening()
                else void voice.startListening()
                audio.uiTick()
              }}
              aria-label={st.listening ? t(lang, 'voiceStop') : t(lang, 'voiceStart')}
            >
              {st.listening ? t(lang, 'voiceStop') : t(lang, 'voiceStart')}
            </button>
            <div className="voice-status">
              <div>
                {t(lang, 'voiceStatus')}: {st.listening ? t(lang, 'voiceListening') : t(lang, 'voiceIdle')}
              </div>
              {st.lastHeard && (
                <div className="voice-heard">
                  {t(lang, 'voiceHeard')}: {st.lastHeard}
                </div>
              )}
              {st.interimText && <div className="voice-heard">…{st.interimText}</div>}
              {st.micError && <div className="voice-error">{st.micError}</div>}
            </div>
          </div>

          {/* 口令列表 */}
          <div className="voice-section">
            <div className="ctl-label">{t(lang, 'voiceCommands')}</div>
            <div className="voice-cmd-list">
              {COMMANDS.map((c) => (
                <div key={c.action} className="voice-cmd">
                  <span className="voice-cmd-kw">{lang === 'zh' ? c.zh[0] : c.en[0]}</span>
                  <span className="voice-cmd-act">{t(lang, `cmd-${c.action}` as import('@/app/i18n').I18nKey)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 诊断 */}
          <div className="voice-section">
            <button type="button" className="ctl-btn" disabled={diagBusy} onClick={() => void runDiag()}>
              {diagBusy ? '…' : t(lang, 'voiceDiag')}
            </button>
            {diag && (
              <div className="voice-diag-list">
                {diag.map((d) => (
                  <div key={d.key} className={`voice-diag-item${d.ok ? '' : ' bad'}`}>
                    <span className="voice-diag-mark">{d.ok ? '✓' : '✗'}</span>
                    <span>{d.msg}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 实体化物料 */}
          <div className="voice-section">
            <div className="ctl-label">{t(lang, 'voiceHardware')}</div>
            <div className="voice-hw">
              {lang === 'zh' ? (
                <>
                  <p>树莓派 5（4GB）+ ReSpeaker 4-Mic Array + USB 声卡</p>
                  <p>或：ESP32-S3 + INMP441 麦克风（轻量口令）</p>
                  <p>软件：faster-whisper small（int8，树莓派可跑）/ openWakeWord（唤醒词）</p>
                </>
              ) : (
                <>
                  <p>Raspberry Pi 5 (4GB) + ReSpeaker 4-Mic Array + USB audio</p>
                  <p>Or: ESP32-S3 + INMP441 mic (lightweight commands)</p>
                  <p>Software: faster-whisper small (int8) / openWakeWord</p>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
