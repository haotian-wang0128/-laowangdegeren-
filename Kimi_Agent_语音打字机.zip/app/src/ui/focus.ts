// 浮层关闭后的 IME 焦点恢复
// 在浮层完成关闭后的多个时机重试（rAF / 30ms / 120ms），覆盖点击按钮默认焦点、
// 抽屉卸载导致的焦点回落等竞态；用户正在表单控件中编辑时不抢焦点。
import { useAppStore } from '@/app/store'

function tryFocus(): void {
  const s = useAppStore.getState()
  if (!s.imeMode) return
  const ae = document.activeElement as HTMLElement | null
  if (ae?.id === 'ime-hidden') return // 已就位
  if (
    ae &&
    ae !== document.body &&
    (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA' || ae.tagName === 'SELECT' || ae.isContentEditable)
  ) {
    return // 用户正在其他表单控件中，不抢焦点
  }
  const ta = document.getElementById('ime-hidden') as HTMLTextAreaElement | null
  ta?.focus({ preventScroll: true })
}

export function scheduleImeFocus(): void {
  requestAnimationFrame(() => tryFocus())
  window.setTimeout(tryFocus, 30)
  window.setTimeout(tryFocus, 120)
}
