// 主控制台：标题、语言切换、顶部提示、相机三档、拆解滑杆、各开关、文稿操作、状态行
import { useEffect, useRef, useState } from 'react'
import { useAppStore } from '@/app/store'
import { t } from '@/app/i18n'
import type { I18nKey } from '@/app/i18n'
import { doc } from '@/document/model'
import { machine } from '@/machine/sequencer'
import { audio } from '@/audio/synth'
import { bus } from '@/app/bus'
import { SAMPLE_TEXT } from './sampleText'
import { scheduleImeFocus } from './focus'

function ControlButton({
  label,
  active,
  disabled,
  onClick,
  aria,
}: {
  label: string
  active?: boolean
  disabled?: boolean
  onClick: () => void
  aria?: string
}) {
  return (
    <button
      type="button"
      className={`ctl-btn${active ? ' active' : ''}`}
      onClick={onClick}
      aria-label={aria ?? label}
      aria-pressed={active}
      disabled={disabled}
      aria-disabled={disabled || undefined}
    >
      {label}
    </button>
  )
}

export function Console() {
  const s = useAppStore()
  const lang = s.lang
  const [clearArmed, setClearArmed] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)
  const [noticeDetail, setNoticeDetail] = useState('')
  const noticeTimer = useRef<number | null>(null)
  const sampleTimer = useRef<number | null>(null)

  // 顶部提示：瞬时提示自动消退，持续状态（拆解/页满）常驻
  useEffect(() => {
    const off = bus.on('ui:notice', (p) => {
      if (!p.key) return
      setNotice(p.key)
      setNoticeDetail(p.detail ?? '')
      if (['noticeLineFull', 'draftRestored', 'exportDone', 'noticeBusy', 'noticeRejected'].includes(p.key)) {
        if (noticeTimer.current) window.clearTimeout(noticeTimer.current)
        noticeTimer.current = window.setTimeout(() => {
          setNotice(null)
          setNoticeDetail('')
          scheduleImeFocus() // 草稿恢复等提示消退后归还 IME 焦点
        }, 2600)
      }
    })
    return off
  }, [])

  // 拆解/页满 常驻提示
  useEffect(() => {
    if (s.explode > 8) setNotice('noticeExplode')
    else if (s.noticeKey === null && notice === 'noticeExplode') setNotice(null)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.explode])

  useEffect(() => {
    const offFull = bus.on('doc:pageFull', () => setNotice('noticePageFull'))
    const offNew = bus.on('doc:newSheet', () => setNotice(null))
    return () => {
      offFull()
      offNew()
    }
  }, [])

  const runSample = () => {
    if (sampleTimer.current) {
      window.clearInterval(sampleTimer.current)
      sampleTimer.current = null
      return
    }
    const text = SAMPLE_TEXT[lang]
    let i = 0
    sampleTimer.current = window.setInterval(() => {
      if (i >= text.length || doc.isPageFull()) {
        if (sampleTimer.current) window.clearInterval(sampleTimer.current)
        sampleTimer.current = null
        return
      }
      const ch = text[i++]
      if (ch === '\n') machine.carriageReturn()
      else machine.typeChar(ch)
    }, 140)
  }

  const handleClear = () => {
    if (!clearArmed) {
      setClearArmed(true)
      window.setTimeout(() => {
        setClearArmed(false)
        scheduleImeFocus() // 取消清空（超时未确认）后归还 IME 焦点
      }, 3200)
      return
    }
    doc.clear()
    machine.flushVisuals()
    setClearArmed(false)
    audio.uiTick()
    scheduleImeFocus() // 确认清空后归还 IME 焦点
  }

  // 语音状态提示
  useEffect(() => {
    const off = bus.on('voice:changed', () => {
      // 触发 re-render 以更新语音按钮 active 状态
      useAppStore.getState().bumpDoc()
    })
    return off
  }, [])

  const modes = [
    ['write', t(lang, 'modeWrite')],
    ['mechanism', t(lang, 'modeMechanism')],
    ['inspect', t(lang, 'modeInspect')],
  ] as const

  return (
    <>
      {/* 标题块 */}
      <header className="masthead">
        <div className="masthead-rule" />
        <h1 className="masthead-title">{t(lang, 'title')}</h1>
        <p className="masthead-sub">{t(lang, 'subtitle')}</p>
        <p className="masthead-motto">{t(lang, 'motto')}</p>
      </header>

      {/* 语言切换 */}
      <button
        type="button"
        className="lang-switch"
        onClick={() => {
          s.setLang(lang === 'zh' ? 'en' : 'zh')
          audio.uiTick()
        }}
        aria-label="Switch language / 切换语言"
      >
        {t(lang, 'langSwitch')}
      </button>

      {/* 顶部提示 */}
      <div className={`notice-bar${notice ? ' show' : ''}`} role="status" aria-live="polite">
        {notice ? t(lang, notice as I18nKey) + noticeDetail : ''}
      </div>

      {/* 底部控制台 */}
      <section className="console" aria-label={lang === 'zh' ? '机械控制台' : 'Machine console'}>
        <div className="console-row">
          <div className="ctl-group" role="group" aria-label="Camera">
            {modes.map(([m, label]) => (
              <ControlButton key={m} label={label} active={s.cameraMode === m} onClick={() => s.setCameraMode(m)} />
            ))}
          </div>

          <div className="ctl-group explode-group">
            <label htmlFor="explode-slider" className="ctl-label">
              {t(lang, 'explode')} · {Math.round(s.explode)}%
            </label>
            <input
              id="explode-slider"
              type="range"
              min={0}
              max={100}
              step={1}
              value={s.explode}
              onChange={(e) => s.setExplode(Number(e.target.value))}
              className="explode-slider"
              aria-valuetext={`${Math.round(s.explode)}%`}
            />
          </div>

          <div className="ctl-group" role="group" aria-label="Toggles">
            <ControlButton label={t(lang, 'cutaway')} active={s.cutaway} onClick={() => s.toggleCutaway()} />
            <ControlButton label={t(lang, 'sound')} active={s.sound} onClick={() => s.toggleSound()} />
            <ControlButton label={t(lang, 'autoReturn')} active={s.autoReturn} onClick={() => s.toggleAutoReturn()} />
            <ControlButton label={t(lang, 'ime')} active={s.imeMode} onClick={() => s.toggleIme()} />
            <ControlButton label={t(lang, 'voiceKey')} active={s.voicePanelOpen} onClick={() => s.setVoicePanelOpen(!s.voicePanelOpen)} />
          </div>

          <div className="ctl-group" role="group" aria-label="Document">
            <ControlButton label={t(lang, 'sample')} onClick={runSample} />
            <ControlButton
              label={t(lang, 'newSheet')}
              onClick={() => {
                doc.newSheet()
                machine.flushVisuals()
              }}
            />
            <ControlButton
              label={t(lang, 'undo')}
              disabled={s.machineBusy || !doc.canUndo()}
              aria={s.machineBusy ? `${t(lang, 'undo')} — ${t(lang, 'noticeBusy')}` : undefined}
              onClick={() => {
                if (doc.undo()) machine.flushVisuals()
              }}
            />
            <ControlButton
              label={t(lang, 'redo')}
              disabled={s.machineBusy || !doc.canRedo()}
              aria={s.machineBusy ? `${t(lang, 'redo')} — ${t(lang, 'noticeBusy')}` : undefined}
              onClick={() => {
                if (doc.redo()) machine.flushVisuals()
              }}
            />
            <ControlButton
              label={clearArmed ? t(lang, 'clearConfirm') : t(lang, 'clear')}
              active={clearArmed}
              onClick={handleClear}
            />
            <ControlButton label={t(lang, 'export')} onClick={() => s.setExportOpen(true)} />
          </div>
        </div>

        <div className="status-line" aria-live="off" aria-busy={s.machineBusy}>
          <span>
            {t(lang, 'page')} {String(doc.cursor.page + 1).padStart(2, '0')}
          </span>
          <span>
            {t(lang, 'line')} {String(Math.min(doc.cursor.line + 1, 44)).padStart(2, '0')}/44
          </span>
          <span>
            {t(lang, 'col')} {String(doc.cursor.col).padStart(2, '0')}/72
          </span>
          <span>
            {t(lang, 'stats')} {doc.charCount}
          </span>
          <span className="status-hint">{s.cameraMode === 'inspect' ? t(lang, 'hintInspect') : t(lang, 'hintWrite')}</span>
        </div>
      </section>
    </>
  )
}
