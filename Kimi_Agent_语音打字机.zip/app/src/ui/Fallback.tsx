// WebGL 不可用时的暗色降级页
import { useAppStore } from '@/app/store'
import { t } from '@/app/i18n'

export function Fallback() {
  const lang = useAppStore((s) => s.lang)
  const setLang = useAppStore((s) => s.setLang)
  return (
    <div className="fallback">
      <div className="fallback-inner">
        <div className="masthead-rule" />
        <h1 className="masthead-title">{t(lang, 'title')}</h1>
        <p className="masthead-sub">{t(lang, 'subtitle')}</p>
        <p className="masthead-motto">{t(lang, 'motto')}</p>
        <p className="fallback-body">{t(lang, 'fallbackBody')}</p>
        <button type="button" className="ctl-btn" onClick={() => setLang(lang === 'zh' ? 'en' : 'zh')}>
          {t(lang, 'langSwitch')}
        </button>
      </div>
    </div>
  )
}
