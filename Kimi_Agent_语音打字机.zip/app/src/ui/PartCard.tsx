// 检视模式零件卡：中英对照 + 慢速追踪这次击键
import { useAppStore } from '@/app/store'
import { PART_INFO, t } from '@/app/i18n'
import { machine } from '@/machine/sequencer'
import { doc } from '@/document/model'
import { audio } from '@/audio/synth'
import { scheduleImeFocus } from './focus'

export function PartCard() {
  const part = useAppStore((s) => s.selectedPart)
  const lang = useAppStore((s) => s.lang)
  const setSelectedPart = useAppStore((s) => s.setSelectedPart)
  const startTrace = useAppStore((s) => s.startTrace)

  if (!part) return null
  const info = PART_INFO[part]
  if (!info) return null

  const lastChar = (() => {
    const { line, col } = doc.cursor
    if (col > 0) {
      const cell = doc.cellAt(line, col - 1)
      if (cell && cell.length) return cell[cell.length - 1]
    }
    return 'a'
  })()

  const trace = () => {
    startTrace(lastChar)
    machine.startTrace(lastChar)
    audio.uiTick()
  }

  return (
    <aside className="part-card" role="dialog" aria-label={lang === 'zh' ? info.zh : info.en}>
      <div className="part-card-head">
        <div>
          <div className="part-zh">{info.zh}</div>
          <div className="part-en">{info.en}</div>
        </div>
        <button
          type="button"
          className="part-close"
          onClick={() => {
            setSelectedPart(null)
            scheduleImeFocus() // 零件卡关闭后归还 IME 焦点
          }}
          aria-label={t(lang, 'close')}
        >
          ×
        </button>
      </div>
      <p className="part-desc">{lang === 'zh' ? info.descZh : info.descEn}</p>
      <p className="part-desc-alt">{lang === 'zh' ? info.descEn : info.descZh}</p>
      <button type="button" className="ctl-btn trace-btn" onClick={trace}>
        {t(lang, 'trace')}
      </button>
    </aside>
  )
}
