// 文稿状态机 —— 严格 44 行 × 72 列机械规则
// 第 66 列鸣铃 / 满行拒字 / 退格只移光标形成叠印 / Enter 机械回车 / 页满需换新纸
import { bus } from '@/app/bus'

export const LINES_PER_PAGE = 44
export const COLS_PER_LINE = 72
export const BELL_COL = 66

export type Cell = string[] // 叠印层：同一格的多次落字
export type Line = Cell[]
export interface Page {
  lines: Line[]
}
export interface Cursor {
  page: number
  line: number
  col: number
}

interface Snapshot {
  pages: Page[]
  cursor: Cursor
}

const DRAFT_KEY = 'impact-doc-v1'
const UNDO_CAP = 100

function emptyPage(): Page {
  return { lines: Array.from({ length: LINES_PER_PAGE }, () => []) }
}

class DocumentModel {
  pages: Page[] = [emptyPage()]
  cursor: Cursor = { page: 0, line: 0, col: 0 }
  charCount = 0
  private undoStack: Snapshot[] = []
  private redoStack: Snapshot[] = []

  constructor() {
    this.restore()
  }

  // ---- 查询 ----
  get page(): Page {
    return this.pages[this.cursor.page]
  }

  cellAt(line: number, col: number): Cell | undefined {
    return this.pages[this.cursor.page].lines[line][col]
  }

  isPageFull(): boolean {
    return this.cursor.line >= LINES_PER_PAGE
  }

  private snapshot(): Snapshot {
    return JSON.parse(JSON.stringify({ pages: this.pages, cursor: this.cursor })) as Snapshot
  }

  private pushUndo(): void {
    this.undoStack.push(this.snapshot())
    if (this.undoStack.length > UNDO_CAP) this.undoStack.shift()
    this.redoStack = []
  }

  // ---- 落字（数据层原子提交，输入瞬间完成，不依赖动画）----
  // 返回 { ok, bell, reason }；bell = 落字后到达第 66 列
  commitChar(char: string): { ok: boolean; bell: boolean; reason?: 'lineFull' | 'pageFull' } {
    if (this.isPageFull()) return { ok: false, bell: false, reason: 'pageFull' }
    if (this.cursor.col >= COLS_PER_LINE) return { ok: false, bell: false, reason: 'lineFull' }
    this.pushUndo()
    const lineArr = this.page.lines[this.cursor.line]
    if (!lineArr[this.cursor.col]) lineArr[this.cursor.col] = []
    lineArr[this.cursor.col].push(char)
    this.charCount++
    this.cursor.col++
    const bell = this.cursor.col === BELL_COL
    this.persist()
    bus.emit('doc:changed', {})
    return { ok: true, bell }
  }

  // ---- 整段文本原子提交（IME 合成用）----
  // 一次 pushUndo = 一次撤销步；任何长度都不截断，被拒字符显式返回
  commitString(
    text: string,
    autoReturn: boolean,
  ): { jobs: Array<{ char: string; toLine: number; toCol: number; bell: boolean }>; rejected: string } {
    if (!text) return { jobs: [], rejected: '' }
    this.pushUndo()
    const jobs: Array<{ char: string; toLine: number; toCol: number; bell: boolean }> = []
    let rejected = ''
    for (const ch of text) {
      if (ch === '\n' || ch === '\r') {
        if (ch === '\r') continue
        if (this.cursor.line + 1 >= LINES_PER_PAGE) {
          rejected += text.slice(text.indexOf(ch))
          break
        }
        this.cursor.col = 0
        this.cursor.line++
        jobs.push({ char: '\n', toLine: this.cursor.line, toCol: 0, bell: false })
        continue
      }
      if (this.isPageFull()) {
        rejected += ch
        continue
      }
      if (this.cursor.col >= COLS_PER_LINE) {
        if (autoReturn && this.cursor.line + 1 < LINES_PER_PAGE) {
          this.cursor.col = 0
          this.cursor.line++
          jobs.push({ char: '\n', toLine: this.cursor.line, toCol: 0, bell: false })
        } else {
          rejected += ch // 满行拒字：显式记录，绝不静默
          continue
        }
      }
      const lineArr = this.page.lines[this.cursor.line]
      if (!lineArr[this.cursor.col]) lineArr[this.cursor.col] = []
      lineArr[this.cursor.col].push(ch)
      this.charCount++
      this.cursor.col++
      jobs.push({ char: ch, toLine: this.cursor.line, toCol: this.cursor.col, bell: this.cursor.col === BELL_COL })
    }
    this.persist()
    bus.emit('doc:changed', {})
    return { jobs, rejected }
  }

  // ---- 退格：只移动光标，不删除 —— 再次落字即叠印 ----
  backspace(): boolean {
    if (this.cursor.col <= 0) return false
    this.pushUndo()
    this.cursor.col--
    this.persist()
    bus.emit('doc:changed', {})
    return true
  }

  // ---- 机械回车：滑架归位 + 行进一行 ----
  carriageReturn(): boolean {
    if (this.isPageFull()) {
      bus.emit('doc:pageFull', {})
      bus.emit('ui:notice', { key: 'noticePageFull' })
      return false
    }
    this.pushUndo()
    this.cursor.col = 0
    this.cursor.line++
    if (this.cursor.line >= LINES_PER_PAGE) {
      bus.emit('doc:pageFull', {})
      bus.emit('ui:notice', { key: 'noticePageFull' })
    }
    this.persist()
    bus.emit('doc:changed', {})
    return true
  }

  // ---- 换新纸 ----
  newSheet(): void {
    this.pushUndo()
    this.pages.push(emptyPage())
    this.cursor = { page: this.pages.length - 1, line: 0, col: 0 }
    this.persist()
    bus.emit('doc:newSheet', { page: this.cursor.page })
    bus.emit('doc:changed', {})
  }

  // ---- 撤销 / 重做 / 清空 ----
  undo(): boolean {
    const s = this.undoStack.pop()
    if (!s) return false
    this.redoStack.push(this.snapshot())
    this.pages = s.pages
    this.cursor = s.cursor
    this.recount()
    this.persist()
    bus.emit('doc:changed', {})
    return true
  }

  redo(): boolean {
    const s = this.redoStack.pop()
    if (!s) return false
    this.undoStack.push(this.snapshot())
    this.pages = s.pages
    this.cursor = s.cursor
    this.recount()
    this.persist()
    bus.emit('doc:changed', {})
    return true
  }

  clear(): void {
    this.pushUndo()
    this.pages = [emptyPage()]
    this.cursor = { page: 0, line: 0, col: 0 }
    this.charCount = 0
    this.persist()
    bus.emit('doc:changed', {})
  }

  canUndo(): boolean {
    return this.undoStack.length > 0
  }

  canRedo(): boolean {
    return this.redoStack.length > 0
  }

  private recount(): void {
    let n = 0
    for (const p of this.pages) for (const l of p.lines) for (const c of l) n += c.length
    this.charCount = n
  }

  // ---- localStorage 草稿 ----
  persist(): void {
    try {
      localStorage.setItem(DRAFT_KEY, JSON.stringify({ pages: this.pages, cursor: this.cursor }))
    } catch {
      /* 存储不可用时静默 */
    }
  }

  restore(): boolean {
    try {
      const raw = localStorage.getItem(DRAFT_KEY)
      if (!raw) return false
      const data = JSON.parse(raw) as Snapshot
      if (!Array.isArray(data.pages) || !data.cursor) return false
      this.pages = data.pages
      this.cursor = data.cursor
      if (this.cursor.page >= this.pages.length) this.cursor.page = this.pages.length - 1
      this.recount()
      return this.charCount > 0
    } catch {
      return false
    }
  }
}

export const doc = new DocumentModel()
