// 确定性伪随机：以 页/行/列/字符 为种子，同一字符在同一位置永远呈现同一墨色与抖动
export interface InkSample {
  alpha: number // 0.55 – 1.0 墨色浓度
  dx: number // ±0.4px 水平抖动
  dy: number // ±0.4px 垂直抖动
  rot: number // ±0.01 rad 微旋转（铅字并非完美对齐）
}

export function inkSample(page: number, line: number, col: number, char: string, layer = 0): InkSample {
  let h = 2166136261 >>> 0
  const s = `${page}:${line}:${col}:${char}:${layer}`
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  // xorshift 展开成 4 个 [0,1)
  const next = () => {
    h ^= h << 13
    h ^= h >>> 17
    h ^= h << 5
    h >>>= 0
    return h / 4294967296
  }
  return {
    alpha: 0.68 + next() * 0.32,
    dx: (next() - 0.5) * 0.8,
    dy: (next() - 0.5) * 0.8,
    rot: (next() - 0.5) * 0.02,
  }
}
