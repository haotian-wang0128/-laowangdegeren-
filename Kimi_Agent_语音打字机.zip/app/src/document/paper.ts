// 纸面 —— 1488×2104 CanvasTexture，含纤维噪点与边缘暗化
// 落字使用 页/行/列/字符 确定性墨色与 ±0.4px 抖动
import * as THREE from 'three'
import { doc, LINES_PER_PAGE, COLS_PER_LINE } from './model'
import { inkSample } from './ink'

export const PAPER_W = 1488
export const PAPER_H = 2104

const MARGIN_X = 96
const MARGIN_TOP = 128
const MARGIN_BOTTOM = 96
const CHAR_W = (PAPER_W - MARGIN_X * 2) / COLS_PER_LINE // 18px
const LINE_H = (PAPER_H - MARGIN_TOP - MARGIN_BOTTOM) / LINES_PER_PAGE

const BONE = '#e8e0cc'
const NICKEL = '#b08d57'
const INK = '#070605'

// 预生成一次纤维噪点瓦片，避免每次重绘时噪点闪烁
function makeFiberTile(): HTMLCanvasElement {
  const t = document.createElement('canvas')
  t.width = 256
  t.height = 256
  const ctx = t.getContext('2d')!
  ctx.fillStyle = BONE
  ctx.fillRect(0, 0, 256, 256)
  let seed = 1907
  const rnd = () => {
    seed = (seed * 16807) % 2147483647
    return seed / 2147483647
  }
  for (let i = 0; i < 4200; i++) {
    const x = rnd() * 256
    const y = rnd() * 256
    const len = 1 + rnd() * 3
    const dark = rnd() > 0.5
    ctx.strokeStyle = dark ? `rgba(7,6,5,${0.015 + rnd() * 0.035})` : `rgba(255,252,240,${0.03 + rnd() * 0.05})`
    ctx.lineWidth = 0.6
    ctx.beginPath()
    ctx.moveTo(x, y)
    ctx.lineTo(x + len * (rnd() - 0.5), y + len * (rnd() - 0.5))
    ctx.stroke()
  }
  // 少量粗纤维
  for (let i = 0; i < 90; i++) {
    const x = rnd() * 256
    const y = rnd() * 256
    ctx.strokeStyle = `rgba(120,100,70,${0.04 + rnd() * 0.05})`
    ctx.lineWidth = 0.9
    ctx.beginPath()
    ctx.moveTo(x, y)
    ctx.lineTo(x + (rnd() - 0.5) * 9, y + (rnd() - 0.5) * 9)
    ctx.stroke()
  }
  return t
}

class PaperTexture {
  canvas: HTMLCanvasElement
  texture: THREE.CanvasTexture
  private ctx: CanvasRenderingContext2D
  private fiber: HTMLCanvasElement

  constructor() {
    this.canvas = document.createElement('canvas')
    this.canvas.width = PAPER_W
    this.canvas.height = PAPER_H
    this.ctx = this.canvas.getContext('2d')!
    this.fiber = makeFiberTile()
    this.texture = new THREE.CanvasTexture(this.canvas)
    this.texture.colorSpace = THREE.SRGBColorSpace
    this.texture.anisotropy = 8
    this.redraw()
  }

  redraw(): void {
    const ctx = this.ctx
    // 纸基：纤维噪点平铺
    const pat = ctx.createPattern(this.fiber, 'repeat')!
    ctx.fillStyle = pat
    ctx.fillRect(0, 0, PAPER_W, PAPER_H)

    // 边缘暗化（四边线性渐晕 + 四角）
    const edge = 130
    const grads: Array<[number, number, number, number, number, number]> = [
      [0, 0, 0, edge, PAPER_W, edge], // 顶
      [0, PAPER_H, 0, PAPER_H - edge, PAPER_W, edge], // 底
      [0, 0, edge, 0, edge, PAPER_H], // 左
      [PAPER_W, 0, PAPER_W - edge, 0, edge, PAPER_H], // 右
    ]
    for (const [x0, y0, x1, y1, w, h] of grads) {
      const g = ctx.createLinearGradient(x0, y0, x1, y1)
      g.addColorStop(0, 'rgba(7,6,5,0.22)')
      g.addColorStop(1, 'rgba(7,6,5,0)')
      ctx.fillStyle = g
      ctx.fillRect(Math.min(x0, x1), Math.min(y0, y1), w, h)
    }

    // 页码（顶部居中，Georgia 小号）
    ctx.fillStyle = 'rgba(7,6,5,0.45)'
    ctx.font = `26px Georgia, serif`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText(`— ${doc.cursor.page + 1} —`, PAPER_W / 2, 56)

    // 落字
    const page = doc.pages[doc.cursor.page]
    const fontPx = Math.round(LINE_H * 0.62)
    ctx.font = `${fontPx}px "Courier Prime", "Courier New", monospace`
    for (let li = 0; li < page.lines.length; li++) {
      const cells = page.lines[li]
      for (let ci = 0; ci < cells.length; ci++) {
        const cell = cells[ci]
        if (!cell) continue
        for (let layer = 0; layer < cell.length; layer++) {
          const ch = cell[layer]
          const ink = inkSample(doc.cursor.page, li, ci, ch, layer)
          const cx = MARGIN_X + ci * CHAR_W + CHAR_W / 2 + ink.dx
          const cy = MARGIN_TOP + li * LINE_H + LINE_H / 2 + ink.dy
          ctx.save()
          ctx.translate(cx, cy)
          ctx.rotate(ink.rot)
          ctx.fillStyle = `rgba(20,14,8,${(ink.alpha * (layer === 0 ? 1 : 0.85)).toFixed(3)})`
          ctx.fillText(ch, 0, 0)
          ctx.restore()
        }
      }
    }

    // 光标：镍色细刻线
    if (!doc.isPageFull()) {
      const cx = MARGIN_X + doc.cursor.col * CHAR_W
      const cy = MARGIN_TOP + doc.cursor.line * LINE_H
      ctx.strokeStyle = NICKEL
      ctx.globalAlpha = 0.75
      ctx.lineWidth = 2
      ctx.strokeRect(cx + 1, cy + 3, CHAR_W - 2, LINE_H - 6)
      ctx.globalAlpha = 1
    }

    // 纸面整体做旧：ink 色极低透明度覆盖
    ctx.fillStyle = INK
    ctx.globalAlpha = 0.03
    ctx.fillRect(0, 0, PAPER_W, PAPER_H)
    ctx.globalAlpha = 1

    this.texture.needsUpdate = true
  }
}

export const paperTexture = new PaperTexture()
