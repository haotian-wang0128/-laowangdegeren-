// DOCX 导出：按机械页分页，Courier Prime，叠印可选保留策略
import { Document, Packer, Paragraph, TextRun, PageBreak, LineRuleType } from 'docx'
import { doc, LINES_PER_PAGE } from '@/document/model'
import type { OverstrikePolicy } from '@/app/store'

function lineText(cells: string[][], policy: OverstrikePolicy): string {
  let out = ''
  for (let c = 0; c < cells.length; c++) {
    const cell = cells[c]
    if (!cell || cell.length === 0) {
      out += ' '
      continue
    }
    if (cell.length === 1) {
      out += cell[0]
    } else if (policy === 'mark') {
      out += cell.join('⁄') // 保留叠印标记
    } else {
      out += cell[cell.length - 1] // 最上层为准
    }
  }
  return out.replace(/\s+$/, '')
}

export async function exportDocx(policy: OverstrikePolicy): Promise<void> {
  const children: Paragraph[] = []
  doc.pages.forEach((page, pi) => {
    if (pi > 0) {
      children.push(new Paragraph({ children: [new PageBreak()] }))
    }
    for (let li = 0; li < LINES_PER_PAGE; li++) {
      const text = lineText(page.lines[li] ?? [], policy)
      children.push(
        new Paragraph({
          children: [new TextRun({ text: text || ' ', font: 'Courier Prime', size: 22 })],
          spacing: { line: 380, lineRule: LineRuleType.EXACT },
        }),
      )
    }
  })

  const document = new Document({
    title: 'THE IMPACT No. 01',
    creator: 'THE IMPACT No. 01 — 机械文稿编辑器',
    sections: [
      {
        properties: {
          page: {
            size: { width: 11906, height: 16838 }, // A4 twips
            margin: { top: 1134, bottom: 1134, left: 1134, right: 1134 },
          },
        },
        children,
      },
    ],
  })

  const blob = await Packer.toBlob(document)
  const url = URL.createObjectURL(blob)
  const a = window.document.createElement('a')
  a.href = url
  a.download = 'THE-IMPACT-No01.docx'
  window.document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 4000)
}
