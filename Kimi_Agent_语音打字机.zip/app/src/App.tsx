// 应用根：全局键盘路由、事件总线接线、WebGL 探测与降级
import { useEffect, useMemo } from 'react'
import { useAppStore } from '@/app/store'
import { bus } from '@/app/bus'
import { machine } from '@/machine/sequencer'
import { doc } from '@/document/model'
import { paperTexture } from '@/document/paper'
import { wireAudio } from '@/audio/synth'
import { TypewriterScene } from '@/scene/TypewriterScene'
import { Console } from '@/ui/Console'
import { PartCard } from '@/ui/PartCard'
import { ExportDrawer } from '@/ui/ExportDrawer'
import { ImeAdapter } from '@/ui/ImeAdapter'
import { VoicePanel } from '@/ui/VoicePanel'
import { Fallback } from '@/ui/Fallback'
import { voice } from '@/voice/controller'
import './App.css'

function webglAvailable(): boolean {
  try {
    const c = document.createElement('canvas')
    return !!(c.getContext('webgl2') ?? c.getContext('webgl'))
  } catch {
    return false
  }
}

export default function App() {
  const ok = useMemo(webglAvailable, [])
  const lang = useAppStore((s) => s.lang)

  useEffect(() => {
    document.documentElement.lang = lang === 'zh' ? 'zh-CN' : 'en'
  }, [lang])

  // 总线接线：文稿变更 → 纸面重绘 + 状态行刷新；铃 → 机械铃震
  useEffect(() => {
    const offAudio = wireAudio()
    const offChange = bus.on('doc:changed', () => {
      paperTexture.redraw()
      useAppStore.getState().bumpDoc()
    })
    const offBell = bus.on('doc:bell', () => machine.ringBell())
    const unlock = () => bus.emit('audio:unlock', {})
    window.addEventListener('pointerdown', unlock)
    window.addEventListener('keydown', unlock)
    if (document.fonts) {
      void document.fonts.load('20px "Courier Prime"').then(() => paperTexture.redraw())
      void document.fonts.ready.then(() => paperTexture.redraw())
    }
    paperTexture.redraw()
    if (doc.charCount > 0) bus.emit('ui:notice', { key: 'draftRestored' })
    // 调试句柄
    ;(window as unknown as { __impact: unknown }).__impact = { doc, paperTexture, machine, voice }
    return () => {
      offAudio()
      offChange()
      offBell()
      window.removeEventListener('pointerdown', unlock)
      window.removeEventListener('keydown', unlock)
    }
  }, [])

  // 全局键盘 → 机械链路（IME 模式下交给隐藏 textarea）
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const s = useAppStore.getState()
      // Escape 关闭浮层（IME 模式下也生效；焦点归还由 ImeAdapter 的订阅完成）
      if (e.key === 'Escape') {
        if (s.exportOpen) s.setExportOpen(false)
        else if (s.voicePanelOpen) s.setVoicePanelOpen(false)
        else if (s.selectedPart) s.setSelectedPart(null)
        return
      }
      // 语音键：F9 切换监听，F10 切换模式（全程不碰键盘的备用方案）
      if (e.key === 'F9') {
        e.preventDefault()
        if (voice.state.listening) voice.stopListening()
        else void voice.startListening()
        return
      }
      if (e.key === 'F10') {
        e.preventDefault()
        voice.toggleMode()
        return
      }
      if (s.imeMode) return
      const target = e.target as HTMLElement | null
      if (target && (target.tagName === 'TEXTAREA' || (target.tagName === 'INPUT' && target.getAttribute('type') !== 'range'))) return
      if (e.ctrlKey || e.metaKey) {
        const k = e.key.toLowerCase()
        if (k === 'z' || k === 'y') {
          e.preventDefault()
          // 机械队列忙碌时不静默忽略：明确提示
          if (s.machineBusy || machine.isBusy()) {
            bus.emit('ui:notice', { key: 'noticeBusy' })
            return
          }
          if (k === 'y' || e.shiftKey) {
            if (doc.redo()) machine.flushVisuals()
          } else {
            if (doc.undo()) machine.flushVisuals()
          }
        }
        return
      }
      if (e.key === 'Enter') {
        e.preventDefault()
        machine.carriageReturn()
      } else if (e.key === 'Backspace') {
        e.preventDefault()
        machine.backspace()
      } else if (e.key.length === 1) {
        e.preventDefault()
        machine.typeChar(e.key)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  if (!ok) return <Fallback />

  return (
    <div className="app-root">
      <TypewriterScene />
      <Console />
      <PartCard />
      <ExportDrawer />
      <ImeAdapter />
      <VoicePanel />
    </div>
  )
}
