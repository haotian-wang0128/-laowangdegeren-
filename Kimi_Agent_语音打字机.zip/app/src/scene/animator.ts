// 场景动画器：每帧统一驱动 爆炸拆解 / 击键联动 / 滑架步进 / 传动链高亮
import * as THREE from 'three'
import { machine } from '@/machine/sequencer'
import { doc } from '@/document/model'
import { useAppStore } from '@/app/store'
import { allParts, getPart, highlightGroup, clearHighlights, setInspectHighlight, getInspectHighlight } from './registry'
import { keyIdForChar } from '@/machine/keymap'
import { setShellCutaway } from './materials'

const STEP = 0.0072 // 每列滑架步进（米）
const LINE_ANGLE = 0.0968 // 每行滚筒转角（弧度）
const TOOTH = (Math.PI * 2) / 16

// 平滑跟随的内部状态
let carriageX = 0
let platenRot = 0
let wheelRot = 0
let paperY = -0.104
let appliedHL: THREE.Group[] = []
let lastCutaway: boolean | null = null

function paperYForLine(line: number): number {
  // 让当前行对准打印点：local print y = 0.023
  const canvasY = 149.45 + 42.909 * Math.min(line, 43)
  const scaleY = 0.297 / 2104
  return 0.023 - (1052 - canvasY) * scaleY
}

function lerp(cur: number, target: number, k: number, dt: number): number {
  const f = 1 - Math.exp(-k * dt)
  return cur + (target - cur) * f
}

function setHighlight(groups: THREE.Group[]): void {
  if (groups.length === appliedHL.length && groups.every((g, i) => g === appliedHL[i])) return
  clearHighlights()
  for (const g of groups) highlightGroup(g)
  appliedHL = groups
}

const TRACE_CHAIN: Record<string, (keyId: string) => string[]> = {
  keycap: (id) => [`keycap:${id}`],
  keylever: (id) => [`keylever:${id}`],
  link: (id) => [`link:${id}`],
  typebar: (id) => [`typebar:${id}`],
  vibrator: () => ['vibrator'],
  escapement: () => ['escapement', 'escape-wheel'],
  carriage: () => ['carriage'],
}

export function animateMachine(dt: number, now: number): void {
  const s = useAppStore.getState()
  const m = machine.motion
  const e = s.explode / 100
  const rm = s.reducedMotion

  // 剖视外壳
  if (lastCutaway !== s.cutaway) {
    lastCutaway = s.cutaway
    setShellCutaway(s.cutaway)
  }

  // 平滑目标：滑架/滚筒/纸面跟随视觉光标（动画播放位置），空闲时与文稿光标一致
  const spd = rm ? 30 : 12
  carriageX = lerp(carriageX, -machine.view.col * STEP, spd, dt)
  platenRot = lerp(platenRot, -machine.view.line * LINE_ANGLE, rm ? 20 : 5, dt)
  wheelRot = lerp(wheelRot, doc.charCount * TOOTH, 18, dt)
  paperY = lerp(paperY, paperYForLine(machine.view.line), rm ? 20 : 5, dt)

  for (const rec of allParts()) {
    const g = rec.group
    let x = rec.base.x + rec.dir.x * e * rec.scale
    let y = rec.base.y + rec.dir.y * e * rec.scale
    let z = rec.base.z + rec.dir.z * e * rec.scale

    switch (rec.type) {
      case 'keycap':
        if (m.activeKey && rec.id === `keycap:${m.activeKey}`) y -= 0.0045 * m.keyT
        break
      case 'keylever':
        g.rotation.x = m.activeKey && rec.id === `keylever:${m.activeKey}` ? -0.16 * m.keyT : 0
        break
      case 'link':
        if (m.activeKey && rec.id === `link:${m.activeKey}`) y -= 0.013 * m.linkT
        break
      case 'typebar':
        if (rec.qRest && rec.qStrike) {
          const t = m.activeKey && rec.id === `typebar:${m.activeKey}` ? m.typebarT : 0
          g.quaternion.slerpQuaternions(rec.qRest, rec.qStrike, easeOut(t))
        }
        break
      case 'vibrator':
        y += 0.06 * m.ribbonT
        break
      case 'escapement':
        g.rotation.z = 0.28 * m.escapeT
        break
      case 'carriage':
        x += carriageX
        break
      case 'platen':
        g.rotation.x = platenRot
        break
      case 'bell':
        g.rotation.z = m.bellT * 0.3 * Math.sin(now * 0.09)
        break
      case 'paper':
        y += paperY - rec.base.y // 纸面随当前行上移（行送进）
        break
      case 'ribbon':
        g.rotation.y = doc.charCount * 0.02 * (rec.id.endsWith(':l') ? 1 : -1)
        break
      default:
        break
    }
    g.position.set(x, y, z)
  }

  // 逃逸轮（作为 escape-wheel 记录单独设置旋转）
  const wheel = getPart('escape-wheel')
  if (wheel) wheel.group.rotation.z = -wheelRot

  // 高亮：慢速追踪优先，其次检视选中
  if (m.tracePart) {
    const keyId = keyIdForChar(s.traceChar || 'a')
    const ids = (TRACE_CHAIN[m.tracePart] ?? (() => []))(keyId)
    setHighlight(ids.map((id) => getPart(id)?.group).filter((g): g is THREE.Group => !!g))
  } else {
    const g = getInspectHighlight()
    setHighlight(g ? [g] : [])
  }
}

function easeOut(t: number): number {
  return t * t * (3 - 2 * t)
}

export function resetInspectHighlight(): void {
  setInspectHighlight(null)
}
