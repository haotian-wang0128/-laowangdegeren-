// 三档相机：书写 / 机芯 / 检视，平滑过渡；检视档开启轨道控制
import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib'
import { useAppStore } from '@/app/store'
import type { CameraMode } from '@/app/store'

const PRESETS: Record<CameraMode, { pos: [number, number, number]; tgt: [number, number, number] }> = {
  write: { pos: [0, 0.62, 0.78], tgt: [0, 0.14, -0.02] },
  mechanism: { pos: [0.34, 0.12, 0.42], tgt: [0, 0.1, -0.02] },
  inspect: { pos: [0.48, 0.38, 0.58], tgt: [0, 0.15, -0.02] },
}

export function CameraRig() {
  const controls = useRef<OrbitControlsImpl>(null)
  const target = useMemo(() => new THREE.Vector3(...PRESETS.write.tgt), [])
  const tmp = useMemo(() => new THREE.Vector3(), [])

  useFrame((state, dt) => {
    const s = useAppStore.getState()
    const p = PRESETS[s.cameraMode]
    const k = s.reducedMotion ? 1 : 1 - Math.exp(-3.2 * dt)
    state.camera.position.lerp(tmp.set(...p.pos), k)
    target.lerp(tmp.set(...p.tgt), k)
    if (controls.current) {
      controls.current.target.copy(target)
      controls.current.update()
    } else {
      state.camera.lookAt(target)
    }
  })

  const mode = useAppStore((s) => s.cameraMode)
  return (
    <OrbitControls
      ref={controls}
      makeDefault
      enabled={mode === 'inspect'}
      enableDamping
      dampingFactor={0.12}
      minDistance={0.18}
      maxDistance={1.6}
      maxPolarAngle={Math.PI * 0.52}
    />
  )
}
