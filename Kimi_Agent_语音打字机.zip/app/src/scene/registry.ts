// 零件注册表：记录每个可动/可拆解零件的基准位置、爆炸方向与类型
// 场景动画器据此统一驱动 爆炸拆解 / 击键联动 / 传动链高亮
import * as THREE from 'three'

export interface PartRecord {
  id: string
  type: string // frame | keycap | keylever | link | typebar | basket | ribbon | vibrator | escapement | carriage | platen | bail | bell | mainspring | paper | shell
  group: THREE.Group
  base: THREE.Vector3
  dir: THREE.Vector3 // 爆炸方向（已归一）
  scale: number // 爆炸行程
  qRest?: THREE.Quaternion // 字杆静止姿态
  qStrike?: THREE.Quaternion // 字杆撞击姿态
}

const records = new Map<string, PartRecord>()

export function registerPart(
  id: string,
  type: string,
  group: THREE.Group,
  dir: [number, number, number],
  scale: number,
): () => void {
  const rec: PartRecord = {
    id,
    type,
    group,
    base: group.position.clone(),
    dir: new THREE.Vector3(...dir).normalize(),
    scale,
  }
  group.userData.partType = type
  group.userData.partId = id
  records.set(id, rec)
  return () => {
    records.delete(id)
  }
}

export function getPart(id: string): PartRecord | undefined {
  return records.get(id)
}

export function allParts(): IterableIterator<PartRecord> {
  return records.values()
}

export function partsOfType(type: string): PartRecord[] {
  return [...records.values()].filter((r) => r.type === type)
}

// ---- 传动链高亮：换用高亮材质，结束后还原 ----
const highlightMat = new THREE.MeshStandardMaterial({
  color: '#b08d57',
  emissive: '#b08d57',
  emissiveIntensity: 1.6,
  metalness: 0.6,
  roughness: 0.35,
})

const highlighted = new Map<THREE.Mesh, THREE.Material | THREE.Material[]>()

export function highlightGroup(group: THREE.Group): void {
  group.traverse((o) => {
    if (o instanceof THREE.Mesh && !highlighted.has(o)) {
      highlighted.set(o, o.material)
      o.material = highlightMat
    }
  })
}

export function clearHighlights(): void {
  highlighted.forEach((mat, mesh) => {
    mesh.material = mat
  })
  highlighted.clear()
}

// ---- 检视模式选中零件 ----
let inspectGroup: THREE.Group | null = null

export function setInspectHighlight(g: THREE.Group | null): void {
  inspectGroup = g
}

export function getInspectHighlight(): THREE.Group | null {
  return inspectGroup
}
