// 字篮与逐字字杆 / 色带卷轴与提升器 / 逃逸轮与棘爪
import { useMemo } from 'react'
import * as THREE from 'three'
import { usePart } from '../usePart'
import { MAT } from '../materials'
import { KEYS } from '@/machine/keymap'
import type { KeyDef } from '@/machine/keymap'

// 打印点（滚筒前上方切点）
export const PRINT_POINT = new THREE.Vector3(0, 0.258, -0.078)
// 字篮弧
const BASKET_C = new THREE.Vector3(0, 0.185, -0.015)
const BASKET_R = 0.07
const ARC = 1.1

function pivotFor(index: number, total: number): THREE.Vector3 {
  const th = -ARC + (2 * ARC * index) / (total - 1)
  return new THREE.Vector3(BASKET_R * Math.sin(th), BASKET_C.y, BASKET_C.z + BASKET_R * Math.cos(th))
}

function Typebar({ k, index, total }: { k: KeyDef; index: number; total: number }) {
  const pivot = useMemo(() => pivotFor(index, total), [index, total])
  const { qRest, qStrike, len } = useMemo(() => {
    const strike = PRINT_POINT.clone().sub(pivot)
    const len = strike.length()
    strike.normalize()
    // 静止姿态：辐条内聚 —— 字模收拢于篮心下方，撞击时上扬 90°
    const inward = BASKET_C.clone().sub(pivot).normalize()
    const rest = strike.clone().multiplyScalar(0.25).add(inward.multiplyScalar(0.75)).normalize()
    const up = new THREE.Vector3(0, 1, 0)
    return {
      qRest: new THREE.Quaternion().setFromUnitVectors(up, rest),
      qStrike: new THREE.Quaternion().setFromUnitVectors(up, strike),
      len,
    }
  }, [pivot])

  const ref = usePart(`typebar:${k.id}`, 'typebar', [pivot.x * 4, 1.2, 0.6], 0.07, (rec) => {
    rec.qRest = qRest
    rec.qStrike = qStrike
    rec.group.quaternion.copy(qRest)
  })

  return (
    <group ref={ref} position={pivot.toArray()}>
      <mesh position={[0, len * 0.48, 0]} material={MAT.steel} castShadow>
        <cylinderGeometry args={[0.0016, 0.0022, len * 0.96, 6]} />
      </mesh>
      {/* 字模块 */}
      <mesh position={[0, len * 0.965, 0]} material={MAT.nickel}>
        <boxGeometry args={[0.007, 0.011, 0.0035]} />
      </mesh>
    </group>
  )
}

function RibbonSpool({ side }: { side: 1 | -1 }) {
  const ref = usePart(`ribbon:${side === 1 ? 'r' : 'l'}`, 'ribbon', [side * 0.4, 1, 0.2], 0.06)
  return (
    <group ref={ref} position={[side * 0.088, 0.152, -0.028]}>
      <mesh material={MAT.nickel} castShadow>
        <cylinderGeometry args={[0.02, 0.02, 0.007, 24]} />
      </mesh>
      <mesh position={[0, 0.006, 0]} material={MAT.steel}>
        <cylinderGeometry args={[0.004, 0.004, 0.006, 10]} />
      </mesh>
      {[0, 1, 2].map((i) => (
        <mesh key={i} position={[0, 0.0045, 0]} rotation={[0, (i * Math.PI) / 3, 0]} material={MAT.steel}>
          <boxGeometry args={[0.036, 0.0015, 0.003]} />
        </mesh>
      ))}
    </group>
  )
}

function RibbonBand({ side }: { side: 1 | -1 }) {
  const { mid, angle, len } = useMemo(() => {
    const a = new THREE.Vector3(side * 0.075, 0.156, -0.03)
    const b = new THREE.Vector3(side * 0.016, 0.188, -0.053)
    const mid = a.clone().add(b).multiplyScalar(0.5)
    const dx = b.x - a.x
    const dz = b.z - a.z
    return { mid, angle: Math.atan2(-dz, dx), len: Math.hypot(dx, dz) }
  }, [side])
  return (
    <mesh position={mid.toArray()} rotation={[0, angle, 0]} material={MAT.ribbon}>
      <boxGeometry args={[len, 0.008, 0.0012]} />
    </mesh>
  )
}

export function TypeBasket() {
  const basket = usePart('basket', 'basket', [0, -0.5, -0.4], 0.035)
  const vibrator = usePart('vibrator', 'vibrator', [0, 1, 0.4], 0.05)
  const wheel = usePart('escape-wheel', 'escapement', [0.5, -1, 0.3], 0.05)
  const pawls = usePart('escapement', 'escapement', [0.4, -1, 0.5], 0.055)

  const teeth = useMemo(() => Array.from({ length: 16 }, (_, i) => (i * Math.PI * 2) / 16), [])

  return (
    <>
      {/* 字篮弧轨 */}
      <group ref={basket}>
        <mesh position={[BASKET_C.x, BASKET_C.y - 0.004, BASKET_C.z]} rotation={[-Math.PI / 2, 0, 0]} material={MAT.steel}>
          <torusGeometry args={[BASKET_R, 0.0035, 8, 48, ARC * 2]} />
        </mesh>
      </group>

      {/* 逐字字杆 */}
      {KEYS.map((k, i) => (
        <Typebar key={k.id} k={k} index={i} total={KEYS.length} />
      ))}

      {/* 色带卷轴 + 带段 */}
      <RibbonSpool side={-1} />
      <RibbonSpool side={1} />
      <RibbonBand side={-1} />
      <RibbonBand side={1} />

      {/* 色带提升器 */}
      <group ref={vibrator} position={[0, 0.185, -0.055]}>
        <mesh position={[-0.015, 0.004, 0]} material={MAT.nickel}>
          <boxGeometry args={[0.002, 0.014, 0.004]} />
        </mesh>
        <mesh position={[0.015, 0.004, 0]} material={MAT.nickel}>
          <boxGeometry args={[0.002, 0.014, 0.004]} />
        </mesh>
        <mesh position={[0, 0.008, 0]} material={MAT.ribbon}>
          <boxGeometry args={[0.028, 0.013, 0.0009]} />
        </mesh>
      </group>

      {/* 逃逸轮 */}
      <group ref={wheel} position={[0.075, 0.178, -0.09]}>
        <mesh rotation={[Math.PI / 2, 0, 0]} material={MAT.nickel}>
          <cylinderGeometry args={[0.015, 0.015, 0.003, 24]} />
        </mesh>
        {teeth.map((a, i) => (
          <mesh
            key={i}
            position={[Math.cos(a) * 0.0165, Math.sin(a) * 0.0165, 0]}
            rotation={[0, 0, a]}
            material={MAT.nickel}
          >
            <boxGeometry args={[0.0045, 0.0028, 0.0028]} />
          </mesh>
        ))}
      </group>
      {/* 棘爪 */}
      <group ref={pawls} position={[0.075, 0.196, -0.09]}>
        <mesh position={[-0.006, 0, 0]} rotation={[0, 0, 0.5]} material={MAT.steel}>
          <boxGeometry args={[0.003, 0.018, 0.003]} />
        </mesh>
        <mesh position={[0.006, 0, 0]} rotation={[0, 0, -0.5]} material={MAT.steel}>
          <boxGeometry args={[0.003, 0.018, 0.003]} />
        </mesh>
      </group>
    </>
  )
}
