// 机架与外壳：铸铁底座、四脚、顶部/尾部/两侧外壳面板、铭牌
import { usePart } from '../usePart'
import { MAT } from '../materials'

export function FrameBody() {
  const frame = usePart('frame', 'frame', [0, -0.2, 0], 0.015)
  const shellTop = usePart('shell:top', 'shell', [0, 1, 0.35], 0.09)
  const shellRear = usePart('shell:rear', 'shell', [0, 0.4, -1], 0.08)
  const shellL = usePart('shell:l', 'shell', [-1, 0.2, 0], 0.08)
  const shellR = usePart('shell:r', 'shell', [1, 0.2, 0], 0.08)

  return (
    <>
      <group ref={frame}>
        {/* 底座 */}
        <mesh position={[0, 0.025, 0]} material={MAT.frame} castShadow receiveShadow>
          <boxGeometry args={[0.46, 0.05, 0.4]} />
        </mesh>
        {/* 四脚 */}
        {([
          [-0.2, 0.17],
          [0.2, 0.17],
          [-0.2, -0.17],
          [0.2, -0.17],
        ] as const).map(([x, z], i) => (
          <mesh key={i} position={[x, 0.006, z]} material={MAT.platen}>
            <cylinderGeometry args={[0.012, 0.014, 0.012, 16]} />
          </mesh>
        ))}
        {/* 键盘托盘 */}
        <mesh position={[0, 0.068, 0.078]} rotation={[0.16, 0, 0]} material={MAT.frame} castShadow>
          <boxGeometry args={[0.36, 0.016, 0.21]} />
        </mesh>
        {/* 铭牌 */}
        <mesh position={[0, 0.052, 0.2015]} material={MAT.keyring}>
          <boxGeometry args={[0.11, 0.02, 0.002]} />
        </mesh>
        {/* 滑架导轨（固定于机身） */}
        <mesh position={[0, 0.205, -0.128]} rotation={[0, 0, Math.PI / 2]} material={MAT.nickel}>
          <cylinderGeometry args={[0.004, 0.004, 0.46, 12]} />
        </mesh>
        <mesh position={[0, 0.195, -0.1]} rotation={[0, 0, Math.PI / 2]} material={MAT.steel}>
          <cylinderGeometry args={[0.003, 0.003, 0.44, 12]} />
        </mesh>
      </group>

      {/* 外壳面板：剖视时透明 */}
      <group ref={shellTop}>
        <mesh position={[0, 0.152, -0.075]} rotation={[-0.18, 0, 0]} material={MAT.shell} castShadow>
          <boxGeometry args={[0.42, 0.012, 0.17]} />
        </mesh>
      </group>
      <group ref={shellRear}>
        <mesh position={[0, 0.11, -0.168]} rotation={[0.08, 0, 0]} material={MAT.shell} castShadow>
          <boxGeometry args={[0.42, 0.14, 0.012]} />
        </mesh>
      </group>
      <group ref={shellL}>
        <mesh position={[-0.215, 0.1, -0.02]} material={MAT.shell} castShadow>
          <boxGeometry args={[0.012, 0.13, 0.3]} />
        </mesh>
      </group>
      <group ref={shellR}>
        <mesh position={[0.215, 0.1, -0.02]} material={MAT.shell} castShadow>
          <boxGeometry args={[0.012, 0.13, 0.3]} />
        </mesh>
      </group>
    </>
  )
}
