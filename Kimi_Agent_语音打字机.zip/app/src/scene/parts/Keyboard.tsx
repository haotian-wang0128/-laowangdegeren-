// 键盘：四行键帽（骨白圆键 + 镍圈 + 键柄）、键杆、连杆、空格杆
import { useMemo } from 'react'
import { usePart } from '../usePart'
import { MAT } from '../materials'
import { KEYS, SPACEBAR_ID } from '@/machine/keymap'
import type { KeyDef } from '@/machine/keymap'

function Key({ k }: { k: KeyDef }) {
  // 键帽组：击键时整体下沉
  const cap = usePart(`keycap:${k.id}`, 'keycap', [0, 1, 0.25], 0.045 + k.row * 0.012)
  // 键杆组：以后端为枢轴，前端随键帽下压
  const lever = usePart(`keylever:${k.id}`, 'keylever', [0, -1, 0.45], 0.05)
  // 连杆：近字篮的垂直拉杆
  const link = usePart(`link:${k.id}`, 'link', [Math.sign(k.x || 0.001) * 0.6, 0.5, 0.3], 0.035)

  const leverLen = useMemo(() => k.z + 0.06 - 0.012, [k.z])
  const linkX = k.x * 0.82

  return (
    <>
      {/* 键帽 */}
      <group ref={cap} position={[k.x, k.y, k.z]}>
        <mesh position={[0, -0.012, 0]} material={MAT.steel}>
          <cylinderGeometry args={[0.0022, 0.0022, 0.02, 8]} />
        </mesh>
        <mesh material={MAT.keyring} castShadow>
          <cylinderGeometry args={[0.0105, 0.0105, 0.005, 24]} />
        </mesh>
        <mesh position={[0, 0.0018, 0]} material={MAT.keycap} castShadow>
          <cylinderGeometry args={[0.0085, 0.0085, 0.0028, 24]} />
        </mesh>
      </group>
      {/* 键杆：枢轴在机身后部 (k.x, 0.055, -0.06) */}
      <group ref={lever} position={[k.x, 0.055, -0.06]}>
        <mesh position={[0, 0, leverLen / 2]} material={MAT.steel} castShadow>
          <boxGeometry args={[0.004, 0.0028, leverLen]} />
        </mesh>
      </group>
      {/* 连杆 */}
      <group ref={link} position={[linkX, 0.145, 0.022]}>
        <mesh material={MAT.nickel}>
          <cylinderGeometry args={[0.0011, 0.0011, 0.055, 8]} />
        </mesh>
      </group>
    </>
  )
}

export function Keyboard() {
  const space = usePart(`keycap:${SPACEBAR_ID}`, 'keycap', [0, 1, 0.3], 0.05)
  const spaceLever = usePart(`keylever:${SPACEBAR_ID}`, 'keylever', [0, -1, 0.5], 0.05)
  return (
    <>
      {KEYS.map((k) => (
        <Key key={k.id} k={k} />
      ))}
      {/* 空格杆 */}
      <group ref={space} position={[0, 0.068, 0.152]}>
        <mesh material={MAT.frame} castShadow>
          <boxGeometry args={[0.17, 0.007, 0.02]} />
        </mesh>
        <mesh position={[0, 0.0042, 0]} material={MAT.keyring}>
          <boxGeometry args={[0.15, 0.0018, 0.014]} />
        </mesh>
      </group>
      <group ref={spaceLever} position={[0, 0.052, -0.06]}>
        <mesh position={[0, 0, 0.105]} material={MAT.steel}>
          <boxGeometry args={[0.12, 0.003, 0.21]} />
        </mesh>
      </group>
    </>
  )
}
