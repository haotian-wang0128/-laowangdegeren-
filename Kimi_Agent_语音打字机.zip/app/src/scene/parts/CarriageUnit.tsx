// 滑架组件：滑架体、滚筒、压纸杆、边距铃、发条鼓、A4 纸
import { usePart } from '../usePart'
import { MAT } from '../materials'
import { paperTexture } from '@/document/paper'
import * as THREE from 'three'

const paperMat = new THREE.MeshStandardMaterial({
  map: paperTexture.texture,
  color: '#9a917e', // 乘色压暗，避免聚光下过曝吞掉墨色
  roughness: 0.92,
  metalness: 0,
  side: THREE.DoubleSide,
})

export function CarriageUnit() {
  const carriage = usePart('carriage', 'carriage', [0, 0.65, -1], 0.09)
  const platen = usePart('platen', 'platen', [0, 0.9, -1], 0.13)
  const bail = usePart('bail', 'bail', [0, 1, -0.5], 0.11)
  const bell = usePart('bell', 'bell', [-0.6, 0.8, -0.5], 0.11)
  const mainspring = usePart('mainspring', 'mainspring', [-1, 0.25, 0.1], 0.09)
  const paper = usePart('paper', 'paper', [0, 1, -0.25], 0.16)

  return (
    <group ref={carriage} position={[0, 0.235, -0.1]}>
      {/* 端板 */}
      {([-0.185, 0.185] as const).map((x) => (
        <mesh key={x} position={[x, 0.006, 0]} material={MAT.steel} castShadow>
          <boxGeometry args={[0.014, 0.052, 0.08]} />
        </mesh>
      ))}
      {/* 滚筒 */}
      <group ref={platen}>
        <mesh rotation={[0, 0, Math.PI / 2]} material={MAT.platen} castShadow>
          <cylinderGeometry args={[0.03, 0.03, 0.36, 32]} />
        </mesh>
        {([-0.2, 0.2] as const).map((x) => (
          <mesh key={x} position={[x, 0, 0]} rotation={[0, 0, Math.PI / 2]} material={MAT.nickel}>
            <cylinderGeometry args={[0.013, 0.013, 0.022, 16]} />
          </mesh>
        ))}
      </group>
      {/* 压纸杆 + 胶辊 */}
      <group ref={bail} position={[0, 0.036, 0.034]}>
        <mesh rotation={[0, 0, Math.PI / 2]} material={MAT.nickel}>
          <cylinderGeometry args={[0.0022, 0.0022, 0.3, 10]} />
        </mesh>
        {([-0.085, 0.085] as const).map((x) => (
          <mesh key={x} position={[x, 0, 0]} rotation={[0, 0, Math.PI / 2]} material={MAT.platen}>
            <cylinderGeometry args={[0.006, 0.006, 0.012, 12]} />
          </mesh>
        ))}
      </group>
      {/* 边距铃 */}
      <group ref={bell} position={[-0.2, 0.048, 0.012]}>
        <mesh material={MAT.bell} castShadow>
          <sphereGeometry args={[0.012, 18, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
        </mesh>
        <mesh position={[0, -0.006, 0]} material={MAT.steel}>
          <boxGeometry args={[0.004, 0.014, 0.004]} />
        </mesh>
      </group>
      {/* 发条鼓 */}
      <group ref={mainspring} position={[-0.205, 0.004, 0.03]}>
        <mesh rotation={[Math.PI / 2, 0, 0]} material={MAT.nickel} castShadow>
          <cylinderGeometry args={[0.018, 0.018, 0.016, 20]} />
        </mesh>
        <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 0, 0.009]} material={MAT.steel}>
          <cylinderGeometry args={[0.006, 0.006, 0.004, 10]} />
        </mesh>
      </group>
      {/* 页边距挡块 */}
      {([-0.115, 0.115] as const).map((x) => (
        <mesh key={x} position={[x, 0.033, -0.004]} material={MAT.nickel}>
          <boxGeometry args={[0.008, 0.012, 0.01]} />
        </mesh>
      ))}
      {/* A4 纸（1488×2104 CanvasTexture） */}
      <group ref={paper} position={[0, -0.104, -0.0315]}>
        <mesh rotation={[-0.1, 0, 0]} material={paperMat} castShadow>
          <planeGeometry args={[0.21, 0.297]} />
        </mesh>
      </group>
    </group>
  )
}
