// 注册零件的 Hook：挂载时登记，卸载时注销
import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { registerPart, getPart } from './registry'
import type { PartRecord } from './registry'

export function usePart(
  id: string,
  type: string,
  dir: [number, number, number],
  scale: number,
  extra?: (rec: PartRecord) => void,
): React.RefObject<THREE.Group | null> {
  const ref = useRef<THREE.Group>(null)
  const dirKey = dir.join(',')
  useEffect(() => {
    if (!ref.current) return
    const off = registerPart(id, type, ref.current, dir, scale)
    if (extra) {
      const rec = getPart(id)
      if (rec) extra(rec)
    }
    return off
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, type, dirKey, scale])
  return ref
}
