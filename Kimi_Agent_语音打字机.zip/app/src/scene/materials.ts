// 共享材质与配色 —— bone / nickel / ink 三色体系
import * as THREE from 'three'

export const COLOR = {
  bone: '#e8e0cc',
  nickel: '#b08d57',
  ink: '#070605',
  inkSoft: '#14100b',
  steel: '#3a342c',
} as const

export const MAT = {
  // 铸铁机身：近黑，略粗糙
  frame: new THREE.MeshStandardMaterial({ color: '#171310', metalness: 0.55, roughness: 0.6 }),
  // 外壳面板（剖视时透明）
  shell: new THREE.MeshStandardMaterial({
    color: '#1b1611',
    metalness: 0.6,
    roughness: 0.5,
    transparent: true,
    opacity: 1,
  }),
  // 镍件：拉杆、杠杆、导轨
  nickel: new THREE.MeshStandardMaterial({ color: COLOR.nickel, metalness: 0.9, roughness: 0.32 }),
  // 暗钢件：字杆、内部机构
  steel: new THREE.MeshStandardMaterial({ color: '#4a4238', metalness: 0.85, roughness: 0.42 }),
  // 键帽：骨白圆键
  keycap: new THREE.MeshStandardMaterial({ color: COLOR.bone, metalness: 0.05, roughness: 0.55 }),
  // 键帽镍圈
  keyring: new THREE.MeshStandardMaterial({ color: COLOR.nickel, metalness: 0.95, roughness: 0.25 }),
  // 滚筒：硬橡胶近黑
  platen: new THREE.MeshStandardMaterial({ color: '#0e0b09', metalness: 0.1, roughness: 0.85 }),
  // 色带
  ribbon: new THREE.MeshStandardMaterial({ color: '#100b08', metalness: 0.2, roughness: 0.9, side: THREE.DoubleSide }),
  // 铃：镍黄铜
  bell: new THREE.MeshStandardMaterial({ color: '#c9a06a', metalness: 1, roughness: 0.2 }),
  // 纸（材质由 paperTexture 提供 map）
}

export function setShellCutaway(on: boolean): void {
  MAT.shell.opacity = on ? 0.1 : 1
  MAT.shell.depthWrite = !on
  MAT.shell.needsUpdate = true
}
