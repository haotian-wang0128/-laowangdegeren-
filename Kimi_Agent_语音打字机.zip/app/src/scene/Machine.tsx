// 整机装配 + 每帧驱动 + 检视模式射线拾取
import { useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import type { ThreeEvent } from '@react-three/fiber'
import { FrameBody } from './parts/FrameBody'
import { Keyboard } from './parts/Keyboard'
import { TypeBasket } from './parts/TypeBasket'
import { CarriageUnit } from './parts/CarriageUnit'
import { machine } from '@/machine/sequencer'
import { animateMachine } from './animator'
import { setInspectHighlight } from './registry'
import { useAppStore } from '@/app/store'
import { PART_INFO } from '@/app/i18n'

// 点击到的零件类型 → 零件卡 key
function normalizeType(t: string): string {
  if (t === 'shell') return 'frame'
  if (t === 'escape-wheel') return 'escapement'
  return t
}

export function Machine() {
  const flashRef = useRef<THREE.PointLight>(null)

  useFrame((state, dt) => {
    const now = performance.now()
    machine.update(now)
    animateMachine(Math.min(dt, 0.05), now)
    if (flashRef.current) {
      flashRef.current.intensity = machine.motion.impactT * 3
    }
    // 同步忙碌状态（驱动 Undo/Redo 禁用与 aria-busy）
    const s = useAppStore.getState()
    if (machine.motion.busy !== s.machineBusy) s.setMachineBusy(machine.motion.busy)
    void state
  })

  const onPointerDown = (e: ThreeEvent<PointerEvent>) => {
    const s = useAppStore.getState()
    if (s.cameraMode !== 'inspect') return
    e.stopPropagation()
    let o: THREE.Object3D | null = e.object
    while (o && !o.userData.partType) o = o.parent
    if (!o) return
    const type = normalizeType(o.userData.partType as string)
    if (!PART_INFO[type]) return
    s.setSelectedPart(type)
    setInspectHighlight(o as THREE.Group)
  }

  return (
    <group onPointerDown={onPointerDown}>
      <FrameBody />
      <Keyboard />
      <TypeBasket />
      <CarriageUnit />
      {/* 撞击瞬间的暖色闪光 */}
      <pointLight ref={flashRef} position={[0, 0.27, -0.05]} color="#ffd9a0" intensity={0} distance={0.5} decay={1.6} />
    </group>
  )
}
