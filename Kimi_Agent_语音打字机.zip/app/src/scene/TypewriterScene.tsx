// 场景根：近黑背景 + 暖色聚光的电影级机械陈列
import { Canvas } from '@react-three/fiber'
import { Machine } from './Machine'
import { CameraRig } from './CameraRig'
import { COLOR } from './materials'
import { useAppStore } from '@/app/store'

export function TypewriterScene() {
  const setSelectedPart = useAppStore((s) => s.setSelectedPart)

  return (
    <Canvas
      shadows
      dpr={[1, 1.5]}
      camera={{ position: [0, 0.5, 0.8], fov: 40, near: 0.01, far: 20 }}
      gl={{ antialias: true, powerPreference: 'high-performance' }}
      onPointerMissed={() => setSelectedPart(null)}
      style={{ position: 'absolute', inset: 0 }}
    >
      <color attach="background" args={[COLOR.ink]} />
      <fog attach="fog" args={[COLOR.ink, 1.6, 3.4]} />

      {/* 暖色主聚光 */}
      <spotLight
        position={[-0.55, 1.05, 0.65]}
        angle={0.55}
        penumbra={0.65}
        intensity={7}
        decay={1.7}
        color="#f2dfba"
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-bias={-0.0002}
      />
      {/* 镍色轮廓光 */}
      <spotLight position={[0.75, 0.55, -0.75]} angle={0.6} penumbra={0.8} intensity={4} decay={1.7} color="#c99a5f" />
      {/* 正面弱补光 */}
      <pointLight position={[0, 0.22, 0.6]} intensity={1.1} decay={1.7} color="#e8d9b8" />
      <ambientLight intensity={0.1} color="#e8e0cc" />

      {/* 展台地面 */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <circleGeometry args={[2.4, 48]} />
        <meshStandardMaterial color="#0b0906" roughness={0.95} metalness={0} />
      </mesh>

      <Machine />
      <CameraRig />
    </Canvas>
  )
}
