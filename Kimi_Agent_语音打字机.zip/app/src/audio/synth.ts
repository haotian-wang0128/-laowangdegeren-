// Web Audio 纯合成音效 —— 不加载任何音频文件
// 键击/连杆/撞击/逃逸/铃/回车/纸张 等十余种
import { bus } from '@/app/bus'
import { useAppStore } from '@/app/store'

class AudioEngine {
  private ctx: AudioContext | null = null
  private master: GainNode | null = null
  private noiseBuf: AudioBuffer | null = null

  unlock(): void {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume()
      return
    }
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
    if (!AC) return
    this.ctx = new AC()
    this.master = this.ctx.createGain()
    this.master.gain.value = 0.42
    this.master.connect(this.ctx.destination)
    // 预生成 1s 白噪声
    const len = this.ctx.sampleRate
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate)
    const data = this.noiseBuf.getChannelData(0)
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1
  }

  private ready(): boolean {
    if (!useAppStore.getState().sound) return false
    this.unlock()
    return !!(this.ctx && this.master && this.noiseBuf)
  }

  private now(): number {
    return this.ctx!.currentTime
  }

  private noise(dur: number, filterType: BiquadFilterType, freq: number, gain: number, q = 1, freqEnd?: number): void {
    if (!this.ready()) return
    const t = this.now()
    const src = this.ctx!.createBufferSource()
    src.buffer = this.noiseBuf!
    src.loop = true
    const f = this.ctx!.createBiquadFilter()
    f.type = filterType
    f.frequency.setValueAtTime(freq, t)
    if (freqEnd !== undefined) f.frequency.exponentialRampToValueAtTime(Math.max(30, freqEnd), t + dur)
    f.Q.value = q
    const g = this.ctx!.createGain()
    g.gain.setValueAtTime(gain, t)
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
    src.connect(f).connect(g).connect(this.master!)
    src.start(t)
    src.stop(t + dur + 0.02)
  }

  private tone(freq: number, dur: number, gain: number, type: OscillatorType = 'sine', freqEnd?: number): void {
    if (!this.ready()) return
    const t = this.now()
    const o = this.ctx!.createOscillator()
    o.type = type
    o.frequency.setValueAtTime(freq, t)
    if (freqEnd !== undefined) o.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t + dur)
    const g = this.ctx!.createGain()
    g.gain.setValueAtTime(gain, t)
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
    o.connect(g).connect(this.master!)
    o.start(t)
    o.stop(t + dur + 0.02)
  }

  // ---- 十余种机械音效 ----
  keyDown(): void {
    this.noise(0.03, 'highpass', 1800, 0.5)
    this.tone(130, 0.05, 0.25, 'sine', 70)
  }
  keyRelease(): void {
    this.noise(0.02, 'highpass', 2600, 0.2)
  }
  link(): void {
    this.tone(2300, 0.018, 0.16, 'square')
    this.noise(0.015, 'bandpass', 3200, 0.14, 4)
  }
  typebarUp(): void {
    this.noise(0.05, 'bandpass', 900, 0.1, 2, 2400)
  }
  impact(): void {
    // 撞击：噪声爆破 + 低频体鸣
    this.noise(0.07, 'lowpass', 3200, 0.85, 0.8, 380)
    this.tone(165, 0.11, 0.5, 'sine', 55)
    this.tone(92, 0.16, 0.32, 'sine', 40)
  }
  barReturn(): void {
    this.tone(1500, 0.02, 0.1, 'triangle')
    this.noise(0.025, 'bandpass', 1100, 0.1, 3)
  }
  escapement(): void {
    // 棘爪双响
    this.tone(3100, 0.012, 0.2, 'square')
    setTimeout(() => this.tone(2600, 0.012, 0.16, 'square'), 14)
  }
  carriageStep(): void {
    this.noise(0.03, 'bandpass', 950, 0.2, 3)
    this.tone(420, 0.025, 0.1, 'triangle')
  }
  carriageReturn(): void {
    // 滑架长滑 + 到位闷响
    this.noise(0.5, 'bandpass', 420, 0.3, 2, 1750)
    setTimeout(() => {
      this.noise(0.06, 'lowpass', 900, 0.5)
      this.tone(110, 0.12, 0.35, 'sine', 50)
    }, 480)
  }
  lineFeed(): void {
    for (let i = 0; i < 3; i++) setTimeout(() => this.tone(1900, 0.015, 0.13, 'square'), i * 45)
  }
  bell(): void {
    // 边距铃：基频 + 泛音，长衰减
    this.tone(2093, 1.3, 0.32, 'sine')
    this.tone(3160, 0.9, 0.12, 'sine')
    this.tone(4186, 0.5, 0.06, 'sine')
    this.noise(0.015, 'highpass', 4000, 0.25)
  }
  paperLoad(): void {
    this.noise(0.4, 'bandpass', 1400, 0.2, 1.2, 700)
    setTimeout(() => this.noise(0.12, 'bandpass', 2200, 0.12, 2), 300)
  }
  reject(): void {
    // 拒字闷击
    this.tone(140, 0.09, 0.4, 'sine', 60)
    this.noise(0.04, 'lowpass', 700, 0.4)
  }
  drawer(): void {
    this.noise(0.09, 'bandpass', 1500, 0.16, 2, 2400)
    this.tone(800, 0.04, 0.08, 'triangle')
  }
  traceTick(): void {
    this.tone(2800, 0.015, 0.09, 'square')
  }
  uiTick(): void {
    this.tone(1200, 0.02, 0.07, 'triangle')
  }
}

export const audio = new AudioEngine()

// 订阅机械事件 → 合成音效
export function wireAudio(): () => void {
  const offs = [
    bus.on('machine:key', () => audio.keyDown()),
    bus.on('machine:link', () => {
      audio.link()
      audio.typebarUp()
    }),
    bus.on('machine:impact', (p) => {
      if (p.char) audio.impact()
      audio.carriageStep()
    }),
    bus.on('machine:escape', () => audio.escapement()),
    bus.on('machine:barReturn', () => {
      audio.barReturn()
      audio.keyRelease()
    }),
    bus.on('machine:reject', () => audio.reject()),
    bus.on('machine:carriageReturn', () => {
      audio.carriageReturn()
      setTimeout(() => audio.lineFeed(), 460)
    }),
    bus.on('doc:bell', () => audio.bell()),
    bus.on('doc:newSheet', () => audio.paperLoad()),
    bus.on('machine:traceTick', () => audio.traceTick()),
    bus.on('audio:unlock', () => audio.unlock()),
  ]
  return () => offs.forEach((off) => off())
}
