// Whisper 本地引擎：浏览器录音 → POST 到本地 HTTP 服务 → faster-whisper 识别
// 优点：离线、中英混合、隐私；缺点：需本地运行 whisper-server.py
// 服务启动：python3 scripts/whisper-server.py --model small --port 8765
export class WhisperEngine {
  private stream: MediaStream
  private recorder: MediaRecorder | null = null
  private chunks: Blob[] = []
  private timer: number | null = null
  private busy = false
  private stopped = false
  private url = 'http://127.0.0.1:8765/transcribe'

  constructor(stream: MediaStream) {
    this.stream = stream
  }

  start(lang: 'zh' | 'en', cb: { onResult: (r: { text: string; isFinal: boolean }) => void; onError: (e: Error) => void; onEnd: () => void }): void {
    this.stopped = false
    const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : 'audio/webm'
    this.recorder = new MediaRecorder(this.stream, { mimeType: mime, audioBitsPerSecond: 64000 })

    this.recorder.ondataavailable = (e) => {
      if (e.data.size > 0) this.chunks.push(e.data)
    }
    this.recorder.onstop = () => {
      if (this.chunks.length === 0) return
      const blob = new Blob(this.chunks, { type: mime })
      this.chunks = []
      void this.send(blob, lang, cb)
    }

    // 每 2.5s 切片发送一次（平衡延迟与精度）
    this.recorder.start(2500)
    this.timer = window.setInterval(() => {
      if (this.recorder?.state === 'recording') this.recorder.requestData()
    }, 2500)

    // 检测服务可用性
    void fetch('http://127.0.0.1:8765/health', { signal: AbortSignal.timeout(2000) })
      .then((r) => {
        if (!r.ok) throw new Error('Whisper 服务未响应')
      })
      .catch(() => {
        cb.onError(new Error('Whisper 本地服务未启动。请运行：python3 scripts/whisper-server.py --model small'))
        cb.onEnd()
      })
  }

  private async send(blob: Blob, lang: 'zh' | 'en', cb: { onResult: (r: { text: string; isFinal: boolean }) => void; onError: (e: Error) => void }): Promise<void> {
    if (this.busy || this.stopped) return
    this.busy = true
    try {
      const fd = new FormData()
      fd.append('file', blob, 'audio.webm')
      fd.append('lang', lang)
      const res = await fetch(this.url, { method: 'POST', body: fd, signal: AbortSignal.timeout(15000) })
      if (!res.ok) throw new Error(`Whisper 服务 HTTP ${res.status}`)
      const json = (await res.json()) as { text?: string; segments?: Array<{ text: string }> }
      const text = json.text ?? json.segments?.map((s) => s.text).join('') ?? ''
      if (text.trim()) cb.onResult({ text: text.trim(), isFinal: true })
    } catch (e) {
      if (!this.stopped) cb.onError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      this.busy = false
    }
  }

  stop(): void {
    this.stopped = true
    if (this.timer !== null) window.clearInterval(this.timer)
    this.timer = null
    this.recorder?.stop()
    this.recorder = null
  }

  abort(): void {
    this.stopped = true
    if (this.timer !== null) window.clearInterval(this.timer)
    this.timer = null
    this.recorder?.stop()
    this.recorder = null
  }
}
