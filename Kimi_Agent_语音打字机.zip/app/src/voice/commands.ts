// 语音口令表：中文/英文关键词 → 动作
// 采用编辑距离 ≤1 的模糊匹配，容忍识别误差
export type VoiceAction =
  | 'startDictation'
  | 'stopDictation'
  | 'clear'
  | 'newline'
  | 'deleteLastSentence'
  | 'saveText'
  | 'switchToDictation'
  | 'switchToCommand'

export interface CommandDef {
  action: VoiceAction
  zh: string[]
  en: string[]
}

export const COMMANDS: CommandDef[] = [
  { action: 'startDictation', zh: ['开始听写', '开始记录', '听写模式'], en: ['start dictation', 'start typing', 'dictation mode'] },
  { action: 'stopDictation', zh: ['停止听写', '停止记录', '结束听写'], en: ['stop dictation', 'stop typing', 'stop recording'] },
  { action: 'clear', zh: ['清空内容', '清空文稿', '全部删除'], en: ['clear content', 'clear all', 'delete all'] },
  { action: 'newline', zh: ['换行', '回车', '下一行'], en: ['new line', 'newline', 'carriage return'] },
  { action: 'deleteLastSentence', zh: ['删除上一句', '删掉上一句', '删除最后一句'], en: ['delete last sentence', 'remove last sentence', 'delete previous sentence'] },
  { action: 'saveText', zh: ['保存文本', '保存文稿', '导出文稿'], en: ['save text', 'save document', 'export document'] },
  { action: 'switchToDictation', zh: ['听写模式', '进入听写'], en: ['dictation mode', 'switch to dictation'] },
  { action: 'switchToCommand', zh: ['指令模式', '命令模式', '进入指令'], en: ['command mode', 'switch to command'] },
]

// 编辑距离（小样本，够用）
function lev(a: string, b: string): number {
  const m = a.length
  const n = b.length
  if (m === 0) return n
  if (n === 0) return m
  const dp: number[] = Array.from({ length: n + 1 }, (_, i) => i)
  for (let i = 1; i <= m; i++) {
    let prev = dp[0]
    dp[0] = i
    for (let j = 1; j <= n; j++) {
      const tmp = dp[j]
      dp[j] = Math.min(dp[j] + 1, dp[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1))
      prev = tmp
    }
  }
  return dp[n]
}

function normalize(s: string): string {
  return s.toLowerCase().replace(/[，。！？、,.!?\s]/g, '')
}

// 匹配口令：先精确/包含匹配，再编辑距离模糊匹配（避免「停止听写」被「开始听写」抢先命中）
export function matchCommand(text: string): VoiceAction | null {
  const norm = normalize(text)
  if (!norm) return null
  // 第一轮：精确或包含
  for (const cmd of COMMANDS) {
    for (const kw of [...cmd.zh, ...cmd.en]) {
      const nkw = normalize(kw)
      if (norm === nkw || norm.includes(nkw)) return cmd.action
    }
  }
  // 第二轮：编辑距离模糊
  let best: { action: VoiceAction; dist: number } | null = null
  for (const cmd of COMMANDS) {
    for (const kw of [...cmd.zh, ...cmd.en]) {
      const nkw = normalize(kw)
      const maxDist = nkw.length <= 3 ? 1 : 2
      const d = lev(norm, nkw)
      if (Math.abs(norm.length - nkw.length) <= maxDist && d <= maxDist) {
        if (!best || d < best.dist) best = { action: cmd.action, dist: d }
      }
    }
  }
  return best?.action ?? null
}
