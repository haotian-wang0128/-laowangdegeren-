// 语音诊断：自检麦克风、权限、浏览器支持、延迟、Whisper 服务
export interface DiagItem {
  key: string
  ok: boolean
  msg: string
}

export async function runVoiceDiagnostics(): Promise<DiagItem[]> {
  const out: DiagItem[] = []

  // 1. 浏览器支持
  const hasSR = !!(window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown }).SpeechRecognition
    || !!(window as unknown as { webkitSpeechRecognition?: unknown }).webkitSpeechRecognition
  out.push({
    key: 'diag-browser',
    ok: hasSR,
    msg: hasSR
      ? '浏览器支持 Web Speech API'
      : '浏览器不支持 Web Speech API（Chrome / Edge 支持，Firefox/Safari 需 Whisper 引擎）',
  })

  // 2. 麦克风权限与设备
  try {
    const perm = await navigator.permissions.query({ name: 'microphone' as PermissionName })
    out.push({
      key: 'diag-perm',
      ok: perm.state !== 'denied',
      msg: perm.state === 'granted' ? '麦克风权限已允许' : perm.state === 'prompt' ? '麦克风权限待请求（首次使用时会弹出授权框）' : '麦克风权限被拒绝：请浏览器地址栏左侧锁形图标 → 网站设置 → 允许',
    })
  } catch {
    out.push({ key: 'diag-perm', ok: true, msg: '无法查询权限状态（不影响使用）' })
  }

  // 3. 设备枚举
  try {
    const devs = await navigator.mediaDevices.enumerateDevices()
    const mics = devs.filter((d) => d.kind === 'audioinput')
    out.push({
      key: 'diag-device',
      ok: mics.length > 0,
      msg: mics.length > 0 ? `检测到 ${mics.length} 个音频输入设备` : '未检测到麦克风：请检查系统声音输入设置',
    })
  } catch (e) {
    out.push({ key: 'diag-device', ok: false, msg: `设备枚举失败：${e instanceof Error ? e.message : String(e)}` })
  }

  // 4. 实际取流测试
  try {
    const s = await navigator.mediaDevices.getUserMedia({ audio: true })
    const track = s.getAudioTracks()[0]
    const settings = track.getSettings()
    out.push({
      key: 'diag-stream',
      ok: true,
      msg: `麦克风可用：${track.label || '默认设备'}（${settings.sampleRate ?? '?'}Hz）`,
    })
    s.getTracks().forEach((t) => t.stop())
  } catch (e) {
    const name = e instanceof DOMException ? e.name : ''
    out.push({
      key: 'diag-stream',
      ok: false,
      msg:
        name === 'NotAllowedError'
          ? '取流被拒绝：用户或系统拦截了麦克风'
          : name === 'NotFoundError'
            ? '取流失败：未找到可用麦克风'
            : `取流失败：${e instanceof Error ? e.message : String(e)}`,
    })
  }

  // 5. Whisper 本地服务
  try {
    const r = await fetch('http://127.0.0.1:8765/health', { signal: AbortSignal.timeout(1500) })
    const j = (await r.json()) as { model?: string }
    out.push({
      key: 'diag-whisper',
      ok: true,
      msg: `Whisper 本地服务运行中（模型：${j.model ?? 'unknown'}）`,
    })
  } catch {
    out.push({
      key: 'diag-whisper',
      ok: false,
      msg: 'Whisper 本地服务未启动（在线模式可忽略；离线模式请运行 scripts/whisper-server.py）',
    })
  }

  return out
}
