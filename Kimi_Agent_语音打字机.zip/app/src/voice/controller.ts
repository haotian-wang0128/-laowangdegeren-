// 语音控制器状态机：idle → listening(dictation|command) → processing
// 管理录音、识别、动作分发；与机械打字机通过统一接口对接
import { bus } from '@/app/bus'
import { doc } from '@/document/model'
import { machine } from '@/machine/sequencer'
import { useAppStore } from '@/app/store'
import { matchCommand } from './commands'
import type { VoiceAction } from './commands'

export type VoiceMode = 'off' | 'dictation' | 'command'
export type VoiceEngine = 'webspeech' | 'whisper'

export interface VoiceState {
  mode: VoiceMode
  engine: VoiceEngine
  listening: boolean
  micReady: boolean
  micError: string | null
  lastHeard: string
  lastAction: VoiceAction | null
  interimText: string
}

type SttResult = { text: string; isFinal: boolean }
type SttCallbacks = {
  onResult: (r: SttResult) => void
  onError: (e: Error) => void
  onEnd: () => void
}

interface SttEngine {
  start(lang: 'zh' | 'en', cb: SttCallbacks): void
  stop(): void
  abort(): void
}

class VoiceController {
  state: VoiceState = {
    mode: 'off',
    engine: 'webspeech',
    listening: false,
    micReady: false,
    micError: null,
    lastHeard: '',
    lastAction: null,
    interimText: '',
  }

  private engine: SttEngine | null = null
  private stream: MediaStream | null = null
  private dictationBuffer = '' // 已入打字机的听写文本（用于删除上一句）
  private sentenceStart = 0 // 当前句在文稿中的起始位置（用于删除上一句）

  // ---- 麦克风初始化 ----
  async ensureMic(): Promise<boolean> {
    if (this.stream) return true
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, channelCount: 1 },
      })
      this.state.micReady = true
      this.state.micError = null
      bus.emit('voice:changed', {})
      return true
    } catch (e) {
      this.state.micError = e instanceof Error ? e.message : String(e)
      this.state.micReady = false
      bus.emit('voice:changed', {})
      bus.emit('ui:notice', { key: 'noticeMicError' })
      return false
    }
  }

  // ---- 模式控制 ----
  setMode(mode: VoiceMode): void {
    if (this.state.mode === mode) return
    const wasListening = this.state.listening
    if (wasListening) this.stopListening()
    this.state.mode = mode
    this.state.interimText = ''
    bus.emit('voice:changed', {})
    if (mode !== 'off') {
      bus.emit('ui:notice', { key: mode === 'dictation' ? 'noticeDictationOn' : 'noticeCommandOn' })
    }
  }

  toggleMode(): void {
    this.setMode(this.state.mode === 'dictation' ? 'command' : 'dictation')
  }

  // ---- 听写文本送入打字机 ----
  private feedDictation(text: string): void {
    // 逐字送入，保留打字机效果
    for (const ch of text) {
      if (ch === '\n') machine.carriageReturn()
      else machine.typeChar(ch)
    }
    this.dictationBuffer += text
  }

  // ---- 执行口令动作 ----
  private execute(action: VoiceAction): void {
    this.state.lastAction = action
    bus.emit('voice:changed', {})
    switch (action) {
      case 'startDictation':
      case 'switchToDictation':
        this.setMode('dictation')
        break
      case 'stopDictation':
      case 'switchToCommand':
        this.setMode('command')
        break
      case 'clear':
        doc.clear()
        machine.flushVisuals()
        this.dictationBuffer = ''
        bus.emit('ui:notice', { key: 'noticeCleared' })
        break
      case 'newline':
        machine.carriageReturn()
        this.sentenceStart = doc.charCount
        break
      case 'deleteLastSentence':
        this.deleteLastSentence()
        break
      case 'saveText':
        useAppStore.getState().setExportOpen(true)
        bus.emit('ui:notice', { key: 'noticeSaveOpened' })
        break
    }
  }

  // 删除上一句：从 sentenceStart 到当前位置逐字退格（叠印撤销）
  private deleteLastSentence(): void {
    const target = this.sentenceStart
    const steps = doc.charCount - target
    if (steps <= 0) return
    // 逐字 undo（每字一步）直到回到句首
    for (let i = 0; i < steps; i++) doc.undo()
    machine.flushVisuals()
    this.dictationBuffer = this.dictationBuffer.slice(0, Math.max(0, this.dictationBuffer.length - steps))
  }

  // ---- 识别结果处理 ----
  // 供测试直接注入（handleResult 为 private，测试用此方法）
  handleResultForTest(r: SttResult): void {
    this.handleResult(r)
  }

  private handleResult(r: SttResult): void {
    const text = r.text.trim()
    if (!text) return
    this.state.lastHeard = text
    if (r.isFinal) this.state.interimText = ''
    else this.state.interimText = text
    bus.emit('voice:changed', {})

    if (this.state.mode === 'command') {
      if (!r.isFinal) return
      const action = matchCommand(text)
      if (action) {
        bus.emit('ui:notice', { key: 'noticeCmdOk', detail: text })
        this.execute(action)
      } else {
        bus.emit('ui:notice', { key: 'noticeCmdUnknown', detail: text })
      }
    } else if (this.state.mode === 'dictation') {
      if (r.isFinal) this.feedDictation(text)
    }
  }

  // ---- 启停识别 ----
  async startListening(): Promise<void> {
    if (this.state.listening) return
    const ok = await this.ensureMic()
    if (!ok) return

    const lang = useAppStore.getState().lang
    if (this.state.engine === 'webspeech') {
      const { WebSpeechEngine } = await import('./webspeech')
      this.engine = new WebSpeechEngine(this.stream!)
    } else {
      const { WhisperEngine } = await import('./whisper')
      this.engine = new WhisperEngine(this.stream!)
    }

    this.engine.start(lang, {
      onResult: (r) => this.handleResult(r),
      onError: (e) => {
        this.state.micError = e.message
        bus.emit('voice:changed', {})
        bus.emit('ui:notice', { key: 'noticeVoiceError', detail: e.message })
      },
      onEnd: () => {
        // Web Speech 自动重启；Whisper 需要手动重启
        if (this.state.engine === 'whisper' && this.state.listening) {
          void this.restartEngine()
        }
      },
    })
    this.state.listening = true
    bus.emit('voice:changed', {})
    bus.emit('ui:notice', { key: 'noticeListening' })
  }

  private async restartEngine(): Promise<void> {
    if (!this.engine || !this.stream) return
    const lang = useAppStore.getState().lang
    this.engine.abort()
    if (this.state.engine === 'webspeech') {
      const { WebSpeechEngine } = await import('./webspeech')
      this.engine = new WebSpeechEngine(this.stream)
    } else {
      const { WhisperEngine } = await import('./whisper')
      this.engine = new WhisperEngine(this.stream)
    }
    this.engine.start(lang, {
      onResult: (r) => this.handleResult(r),
      onError: (e) => bus.emit('ui:notice', { key: 'noticeVoiceError', detail: e.message }),
      onEnd: () => {
        if (this.state.listening) void this.restartEngine()
      },
    })
  }

  stopListening(): void {
    this.engine?.stop()
    this.engine = null
    this.state.listening = false
    this.state.interimText = ''
    bus.emit('voice:changed', {})
    bus.emit('ui:notice', { key: 'noticeStopped' })
  }

  setEngine(e: VoiceEngine): void {
    if (this.state.engine === e) return
    const was = this.state.listening
    if (was) this.stopListening()
    this.state.engine = e
    bus.emit('voice:changed', {})
    if (was) void this.startListening()
  }
}

export const voice = new VoiceController()
