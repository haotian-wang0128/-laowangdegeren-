// Web Speech API 引擎（Chrome 在线识别，零配置）
// 优点：零模型下载、实时流式；缺点：需联网、Chrome 系浏览器

interface SRResult {
  isFinal: boolean
  [index: number]: { transcript: string; confidence: number }
}
interface SRResultList {
  length: number
  [index: number]: SRResult
}
interface SREvent extends Event {
  resultIndex: number
  results: SRResultList
}
interface SRErrorEvent extends Event {
  error: string
}
interface SRInstance extends EventTarget {
  lang: string
  continuous: boolean
  interimResults: boolean
  maxAlternatives: number
  onresult: ((ev: SREvent) => void) | null
  onerror: ((ev: SRErrorEvent) => void) | null
  onend: (() => void) | null
  start(): void
  stop(): void
  abort(): void
}
type SRConstructor = new () => SRInstance

function getSR(): SRConstructor | null {
  const w = window as unknown as { SpeechRecognition?: SRConstructor; webkitSpeechRecognition?: SRConstructor }
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null
}

export class WebSpeechEngine {
  private rec: SRInstance | null = null
  private stopped = false

  constructor(_stream: MediaStream) {
    void _stream
  }

  start(lang: 'zh' | 'en', cb: { onResult: (r: { text: string; isFinal: boolean }) => void; onError: (e: Error) => void; onEnd: () => void }): void {
    const SR = getSR()
    if (!SR) {
      cb.onError(new Error('当前浏览器不支持 Web Speech API，请使用 Chrome / Edge'))
      cb.onEnd()
      return
    }
    this.stopped = false
    const rec = new SR()
    this.rec = rec
    rec.lang = lang === 'zh' ? 'zh-CN' : 'en-US'
    rec.continuous = true
    rec.interimResults = true
    rec.maxAlternatives = 1

    rec.onresult = (ev) => {
      let interim = ''
      let final = ''
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const r = ev.results[i]
        if (r.isFinal) final += r[0].transcript
        else interim += r[0].transcript
      }
      if (final) cb.onResult({ text: final, isFinal: true })
      if (interim) cb.onResult({ text: interim, isFinal: false })
    }
    rec.onerror = (ev) => {
      const e = ev.error
      if (e === 'not-allowed' || e === 'service-not-allowed') {
        cb.onError(new Error('麦克风权限被拒绝：请在浏览器地址栏左侧点击锁形图标 → 网站设置 → 允许麦克风'))
      } else if (e === 'audio-capture') {
        cb.onError(new Error('未检测到麦克风设备，请检查系统声音输入设置'))
      } else if (e === 'network') {
        cb.onError(new Error('网络连接失败：Web Speech 需要联网，或切换到本地 Whisper 引擎'))
      } else if (e !== 'aborted' && e !== 'no-speech') {
        cb.onError(new Error(`识别错误：${e}`))
      }
    }
    rec.onend = () => {
      if (!this.stopped) cb.onEnd()
    }
    try {
      rec.start()
    } catch (e) {
      cb.onError(e instanceof Error ? e : new Error(String(e)))
    }
  }

  stop(): void {
    this.stopped = true
    this.rec?.stop()
    this.rec = null
  }

  abort(): void {
    this.stopped = true
    this.rec?.abort()
    this.rec = null
  }
}
